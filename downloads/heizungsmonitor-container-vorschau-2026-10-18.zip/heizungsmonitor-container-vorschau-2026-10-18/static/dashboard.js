'use strict';

const STORAGE_KEY = 'heizungsmonitor-config';
const INPUT_CAP = 24;
const PALETTE = ['#62cde5', '#68d9a9', '#f3b966', '#f08bb0', '#b9a0f0', '#8fd18a', '#f0d36a', '#7eb6ff'];


if (typeof t !== 'function') window.t = (text) => String(text == null ? '' : text);
const DEFAULT_INPUTS = [
  {id: 'outside', label: 'Aussentemperatur', address: 202, unit: '°C', divisor: 10, decimals: 1, color: '#62cde5', icon: '🌡', card: true, chart: true, demo: 13.5, kind: 'number'},
  {id: 'supply', label: 'Vorlauf Ist', address: 204, unit: '°C', divisor: 10, decimals: 1, color: '#68d9a9', icon: '♨', card: true, chart: true, demo: 30, kind: 'number'},
  {id: 'target', label: 'Vorlauf Soll', address: 206, unit: '°C', divisor: 10, decimals: 1, color: '#f3b966', icon: '◎', card: true, chart: true, demo: 30.5, kind: 'number'}
];

const DEFAULT_VIEW = {
  title: 'Heizungsmonitor',
  subtitle: 'Temperaturen · Heizkurve · Lesender Zugriff',
  istId: 'supply',
  sollId: 'target',
  tolerance: 1,
  stroke: 3.5,
  intervalSec: 10,
  historyLimit: 120,
  colorValues: false
};

const el = (id) => document.getElementById(id);
const clone = (value) => JSON.parse(JSON.stringify(value));

const ARCHIVE_KEY = 'heizungsmonitor-archive';
const RANGE_KEY = 'heizungsmonitor-range';
const CHART_SIZE_KEY = 'heizungsmonitor-chart-large';
const CHART_HIDE_KEY = 'heizungsmonitor-chart-hidden';
const CHART_FROM_KEY = 'heizungsmonitor-chart-from';
const CHART_TO_KEY = 'heizungsmonitor-chart-to';
const HIDDEN_KEY = 'heizungsmonitor-hidden';
const ARCHIVE_KEEP_MS = 14 * 24 * 60 * 60 * 1000;
const ARCHIVE_GAP_MS = 60 * 1000;
const DRAW_GAP_MS = 20 * 60 * 1000;
const RANGES = [
  {id: '1h', label: '1 Stunde', ms: 60 * 60 * 1000},
  {id: '6h', label: '6 Stunden', ms: 6 * 60 * 60 * 1000},
  {id: '24h', label: '24 Stunden', ms: 24 * 60 * 60 * 1000},
  {id: '7d', label: '7 Tage', ms: 7 * 24 * 60 * 60 * 1000},
  {id: '14d', label: '14 Tage', ms: 14 * 24 * 60 * 60 * 1000}
];

let config = defaultConfig();
let state = {};
let rawState = {};
let archive = [];
let archiveCursor = 0;
let rangeId = '24h';
let chartLarge = false;
let chartHidden = false;
let chartFrom = 0;
let chartTo = 0;
let hiddenSeries = new Set();
let chartModel = null;
let archiveTimer = null;
let archiveReady = false;
let archiveDirty = false;
let interval = null;
let mode = 'demo';
let reading = false;
let writing = false;
const readingSuffix = {};
let inputErrors = {};
let editorReady = false;

function defaultConfig() {
  return {inputs: clone(DEFAULT_INPUTS), view: clone(DEFAULT_VIEW), menus: []};
}

function normalizeColor(value) {
  const text = String(value || '').trim();
  return /^#[0-9a-fA-F]{6}$/.test(text) ? text.toLowerCase() : '';
}

function symbolOf(value) {
  const text = Array.from(String(value || '')).slice(0, 2).join('').trim();
  return text || '●';
}

const SYMBOLS = [
  ['🌡', 'Thermometer'],
  ['❄', 'Kälte'],
  ['♨', 'Wärme'],
  ['🔥', 'Feuer'],
  ['💧', 'Wasser'],
  ['💡', 'Licht'],
  ['🔌', 'Steckdose'],
  ['🚪', 'Tür'],
  ['🌀', 'Lüfter'],
  ['⚙', 'Antrieb'],
  ['⚠', 'Störung'],
  ['🔔', 'Melder'],
  ['▶', 'Lauf'],
  ['⚡', 'Leistung'],
  ['🏠', 'Haus'],
  ['☀', 'Sonne'],
  ['🌙', 'Nacht'],
  ['◎', 'Soll'],
  ['●', 'Punkt'],
  ['⏻', 'Schalter'],
  ['↻', 'Umlauf']
];

const NAME_PRESETS = [
  {name: 'Licht', group: 'Gebäude', icon: '💡', face: 'lamp', unit: ''},
  {name: 'Lichtgruppe', group: 'Gebäude', icon: '💡', face: 'lamp', unit: ''},
  {name: 'Beleuchtung', group: 'Gebäude', icon: '💡', face: 'lamp', unit: ''},
  {name: 'Schalter', group: 'Gebäude', icon: '⏻', face: 'switch', unit: ''},
  {name: 'Taster', group: 'Gebäude', icon: '⏻', face: 'switch', unit: ''},
  {name: 'Steckdose', group: 'Gebäude', icon: '🔌', face: 'switch', unit: ''},
  {name: 'Dimmer', group: 'Gebäude', icon: '💡', face: 'gauge', unit: '%', scaleMin: 0, scaleMax: 100},
  {name: 'Rollladen', group: 'Gebäude', icon: '☀', face: 'switch', unit: ''},
  {name: 'Jalousie', group: 'Gebäude', icon: '☀', face: 'switch', unit: ''},
  {name: 'Markise', group: 'Gebäude', icon: '☀', face: 'switch', unit: ''},
  {name: 'Beschattung', group: 'Gebäude', icon: '☀', face: 'switch', unit: ''},
  {name: 'Tor', group: 'Gebäude', icon: '🚪', face: 'switch', unit: ''},
  {name: 'Tür', group: 'Gebäude', icon: '🚪', face: 'switch', unit: ''},
  {name: 'Fenster', group: 'Gebäude', icon: '🚪', face: 'switch', unit: ''},
  {name: 'Heizung', group: 'Gebäude', icon: '♨', face: 'switch', unit: ''},
  {name: 'Kühlung', group: 'Gebäude', icon: '❄', face: 'switch', unit: ''},
  {name: 'Lüftung', group: 'Gebäude', icon: '🌀', face: 'switch', unit: ''},
  {name: 'Ventilator', group: 'Gebäude', icon: '🌀', face: 'switch', unit: ''},
  {name: 'Klimaanlage', group: 'Gebäude', icon: '❄', face: 'switch', unit: ''},
  {name: 'Pumpe', group: 'Gebäude, Industrie', icon: '💧', face: 'switch', unit: ''},
  {name: 'Umwälzpumpe', group: 'Gebäude', icon: '💧', face: 'switch', unit: ''},
  {name: 'Zirkulationspumpe', group: 'Gebäude', icon: '💧', face: 'switch', unit: ''},
  {name: 'Warmwasser', group: 'Gebäude', icon: '💧', face: 'switch', unit: ''},
  {name: 'Boiler', group: 'Gebäude', icon: '♨', face: 'switch', unit: ''},
  {name: 'Fussbodenheizung', group: 'Gebäude', icon: '♨', face: 'switch', unit: ''},
  {name: 'Thermostat', group: 'Gebäude', icon: '🌡', face: 'gauge', unit: '°C'},
  {name: 'Raumtemperatur', group: 'Gebäude', icon: '🌡', face: 'gauge', unit: '°C'},
  {name: 'Präsenzmelder', group: 'Gebäude', icon: '🔔', face: 'lamp', unit: ''},
  {name: 'Bewegungsmelder', group: 'Gebäude', icon: '🔔', face: 'lamp', unit: ''},
  {name: 'Rauchmelder', group: 'Gebäude', icon: '⚠', face: 'lamp', unit: ''},
  {name: 'Alarm', group: 'Gebäude, Industrie', icon: '⚠', face: 'lamp', unit: ''},
  {name: 'Sirene', group: 'Gebäude', icon: '🔔', face: 'switch', unit: ''},
  {name: 'Motor', group: 'Industrie', icon: '⚙', face: 'switch', unit: ''},
  {name: 'Ventil', group: 'Industrie', icon: '💧', face: 'switch', unit: ''},
  {name: 'Magnetventil', group: 'Industrie', icon: '💧', face: 'switch', unit: ''},
  {name: 'Klappe', group: 'Industrie', icon: '⚙', face: 'switch', unit: ''},
  {name: 'Förderband', group: 'Industrie', icon: '▶', face: 'switch', unit: ''},
  {name: 'Kompressor', group: 'Industrie', icon: '⚙', face: 'switch', unit: ''},
  {name: 'Gebläse', group: 'Industrie', icon: '🌀', face: 'switch', unit: ''},
  {name: 'Rührer', group: 'Industrie', icon: '↻', face: 'switch', unit: ''},
  {name: 'Brenner', group: 'Industrie', icon: '🔥', face: 'switch', unit: ''},
  {name: 'Schütz', group: 'Industrie', icon: '⏻', face: 'switch', unit: ''},
  {name: 'Not-Aus', group: 'Industrie', icon: '⚠', face: 'lamp', unit: ''},
  {name: 'Störung', group: 'Industrie', icon: '⚠', face: 'lamp', unit: ''},
  {name: 'Betrieb', group: 'Industrie', icon: '▶', face: 'lamp', unit: ''},
  {name: 'Freigabe', group: 'Industrie', icon: '⏻', face: 'switch', unit: ''},
  {name: 'Handbetrieb', group: 'Industrie', icon: '⏻', face: 'switch', unit: ''},
  {name: 'Automatik', group: 'Industrie', icon: '⚙', face: 'switch', unit: ''},
  {name: 'Füllstand', group: 'Industrie', icon: '💧', face: 'gauge', unit: '%', scaleMin: 0, scaleMax: 100},
  {name: 'Druck', group: 'Industrie', icon: '⚙', face: 'gauge', unit: 'bar', scaleMin: 0, scaleMax: 10},
  {name: 'Durchfluss', group: 'Industrie', icon: '💧', face: 'gauge', unit: 'm3/h', scaleMin: 0, scaleMax: 100},
  {name: 'Drehzahl', group: 'Industrie', icon: '↻', face: 'gauge', unit: '1/min', scaleMin: 0, scaleMax: 3000},
  {name: 'Leistung', group: 'Industrie', icon: '⚡', face: 'gauge', unit: 'kW', scaleMin: 0, scaleMax: 100},
  {name: 'Zähler', group: 'Industrie', icon: '◎', face: 'number', unit: ''},
  {name: 'Temperatur', group: 'Gebäude, Industrie', icon: '🌡', face: 'gauge', unit: '°C'},
  {name: 'Sollwert', group: 'Gebäude, Industrie', icon: '◎', face: 'gauge', unit: '°C'},
  {name: 'Aussentemperatur', group: 'Gebäude', icon: '☀', face: 'gauge', unit: '°C'},
  {name: 'Vorlauf', group: 'Gebäude', icon: '♨', face: 'gauge', unit: '°C'},
  {name: 'Rücklauf', group: 'Gebäude', icon: '❄', face: 'gauge', unit: '°C'},
  {name: 'Wärmepumpe', group: 'Gebäude', icon: '❄', face: 'switch', unit: ''},
  {name: 'Mischer', group: 'Gebäude, Industrie', icon: '↻', face: 'switch', unit: ''},
  {name: 'Kessel', group: 'Gebäude', icon: '🔥', face: 'switch', unit: ''},
  {name: 'Speicher', group: 'Gebäude', icon: '♨', face: 'gauge', unit: '°C'}
];

const MENU_PRESETS = [
  {name: 'Heizungssteuerung', group: 'Gebäude'},
  {name: 'Lichtsteuerung', group: 'Gebäude'},
  {name: 'Beschattung', group: 'Gebäude'},
  {name: 'Rollladen', group: 'Gebäude'},
  {name: 'Lüftung', group: 'Gebäude'},
  {name: 'Pumpen', group: 'Gebäude, Industrie'},
  {name: 'Warmwasser', group: 'Gebäude'},
  {name: 'Störung', group: 'Gebäude, Industrie'},
  {name: 'Tore und Türen', group: 'Gebäude'},
  {name: 'Bewässerung', group: 'Gebäude'},
  {name: 'Klima', group: 'Gebäude'},
  {name: 'Motoren', group: 'Industrie'},
  {name: 'Energie', group: 'Industrie'},
  {name: 'Alarm', group: 'Gebäude, Industrie'}
];

function applyNamePreset(card, preset) {
  const icon = card.querySelector('[data-field="icon"]');
  if (icon && [...icon.options].some((option) => option.value === preset.icon)) icon.value = preset.icon;
  const face = card.querySelector('[data-field="face"]');
  if (face && preset.face) {
    face.value = preset.face;
    face.dispatchEvent(new Event('change'));
  }
  const unit = card.querySelector('[data-field="unit"]');
  if (unit && preset.unit != null) unit.value = preset.unit;
  if (preset.scaleMin != null) {
    const min = card.querySelector('[data-field="scaleMin"]');
    if (min) min.value = String(preset.scaleMin);
  }
  if (preset.scaleMax != null) {
    const max = card.querySelector('[data-field="scaleMax"]');
    if (max) max.value = String(preset.scaleMax);
  }
}

function presetMatches(preset, query) {
  if (!query) return true;
  const lang = typeof hmLang === 'function' ? hmLang() : 'de';
  const hay = (preset.name + ' ' + t(preset.name) + ' ' + preset.group + ' ' + t(preset.group)).toLocaleLowerCase(lang);
  return hay.includes(query);
}

function symbolSelect(current) {
  const select = document.createElement('select');
  select.dataset.field = 'icon';
  const symbol = symbolOf(current);
  if (!SYMBOLS.some(([mark]) => mark === symbol)) select.append(new Option(symbol + ' ' + t('Eigenes'), symbol));
  for (const [mark, name] of SYMBOLS) select.append(new Option(mark + ' ' + t(name), mark));
  select.value = symbol;
  return select;
}

function pickId(raw, key, fallback, ids) {
  if (raw && typeof raw === 'object' && Object.prototype.hasOwnProperty.call(raw, key)) {
    return ids.has(raw[key]) ? raw[key] : '';
  }
  return ids.has(fallback) ? fallback : '';
}

function clampNumber(value, fallback, min, max) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(max, Math.max(min, number));
}

function normalizeConfig(raw) {
  const fallback = defaultConfig();
  if (!raw || typeof raw !== 'object' || !Array.isArray(raw.inputs)) return fallback;
  const inputs = [];
  const seenIds = new Set();
  const seenAddresses = new Set();
  for (const item of raw.inputs) {
    if (!item || typeof item !== 'object') continue;
    const id = typeof item.id === 'string' && /^[a-zA-Z][a-zA-Z0-9_-]{0,31}$/.test(item.id) ? item.id : '';
    const address = Number(item.address);
    const range = item.range === 'I' || item.range === 'Q' ? item.range : 'V';
    const logo = typeof item.logo === 'string' && /^[a-z][a-z0-9]{0,15}$/.test(item.logo) ? item.logo : '';
    const point = logo + ':' + range + address;
    const divisor = Number(item.divisor);
    const decimals = Number(item.decimals);
    const label = String(item.label || '').trim().slice(0, 40);
    const demo = Number(item.demo);
    if (!id || seenIds.has(id) || seenAddresses.has(point)) continue;
    if (range === 'V' && (!Number.isInteger(address) || address < 0 || address > 65535)) continue;
    if (range !== 'V' && (!Number.isInteger(address) || address < 1 || address > 128)) continue;
    if (!(divisor > 0) || divisor > 100000) continue;
    if (!Number.isInteger(decimals) || decimals < 0 || decimals > 3) continue;
    if (!label) continue;
    if (!Number.isFinite(demo) || Math.abs(demo) > 50000) continue;
    seenIds.add(id);
    seenAddresses.add(point);
    inputs.push({
      id,
      label,
      logo,
      range,
      address,
      unit: String(item.unit ?? '°C').trim().slice(0, 8),
      divisor,
      decimals,
      color: normalizeColor(item.color) || PALETTE[inputs.length % PALETTE.length],
      icon: symbolOf(item.icon),
      card: item.card !== false,
      chart: item.chart !== false,
      demo,
      kind: item.kind === 'switch' || item.face === 'switch' ? 'switch' : 'number',
      face: item.face === 'gauge' || item.face === 'switch' || item.face === 'lamp' ? item.face : (item.kind === 'switch' ? 'switch' : 'number'),
      lamp: lampOf(item.lamp),
      onValue: Number(item.onValue) === 0 ? 0 : 1,
      writable: item.writable === true,
      menus: menuList(item),
      menu: '',
      home: item.home !== false,
      scaleMin: Number.isFinite(Number(item.scaleMin)) ? Number(item.scaleMin) : 0,
      scaleMax: Number.isFinite(Number(item.scaleMax)) ? Number(item.scaleMax) : 80,
      zoneGreen: optionalZone(item.zoneGreen),
      zoneBlue: optionalZone(item.zoneBlue),
      zoneRed: optionalZone(item.zoneRed),
      signalLeft: typeof item.signalLeft === 'string' ? item.signalLeft : '',
      signalRight: typeof item.signalRight === 'string' ? item.signalRight : ''
    });
    if (inputs.length === INPUT_CAP) break;
  }
  if (!inputs.length) return fallback;
  const ids = new Set(inputs.map((input) => input.id));
  const source = raw.view && typeof raw.view === 'object' ? raw.view : {};
  const view = {
    title: String(source.title || '').trim().slice(0, 60) || DEFAULT_VIEW.title,
    subtitle: String(source.subtitle || '').trim().slice(0, 120) || DEFAULT_VIEW.subtitle,
    istId: pickId(source, 'istId', DEFAULT_VIEW.istId, ids),
    sollId: pickId(source, 'sollId', DEFAULT_VIEW.sollId, ids),
    tolerance: clampNumber(source.tolerance, DEFAULT_VIEW.tolerance, 0, 100),
    stroke: clampNumber(source.stroke, DEFAULT_VIEW.stroke, 1, 8),
    intervalSec: Math.round(clampNumber(source.intervalSec, DEFAULT_VIEW.intervalSec, 5, 300)),
    historyLimit: Math.round(clampNumber(source.historyLimit, DEFAULT_VIEW.historyLimit, 20, 240)),
    colorValues: source.colorValues === true
  };
  if (view.istId && view.istId === view.sollId) view.sollId = '';
  const menus = [];
  const menuIds = new Set();
  const menuSource = Array.isArray(raw.menus) ? raw.menus : [];
  for (const item of menuSource) {
    if (!item || typeof item !== 'object') continue;
    const id = typeof item.id === 'string' && /^[a-z][a-z0-9]{0,15}$/.test(item.id) ? item.id : '';
    const name = String(item.name || '').trim().slice(0, 40);
    if (!id || !name || menuIds.has(id)) continue;
    menuIds.add(id);
    menus.push({id, name});
    if (menus.length === 8) break;
  }
  for (const input of inputs) {
    input.menus = (input.menus || []).filter((id) => menuIds.has(id));
    input.menu = input.menus[0] || '';
    if (!ids.has(input.signalLeft) || input.signalLeft === input.id) input.signalLeft = '';
    if (!ids.has(input.signalRight) || input.signalRight === input.id || input.signalRight === input.signalLeft) input.signalRight = '';
  }
  return {inputs, view, menus};
}

function readLocalConfig() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? normalizeConfig(JSON.parse(raw)) : null;
  } catch {
    return null;
  }
}

async function loadConfig() {
  const local = readLocalConfig();
  try {
    const response = await fetch('/api/config', {cache: 'no-store'});
    if (response.ok) {
      const remote = normalizeConfig(await response.json());
      localStorage.setItem(STORAGE_KEY, JSON.stringify(remote));
      return remote;
    }
    if (response.status === 404 && local) {
      const saved = await fetch('/api/config', {
        method: 'PUT',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(local)
      });
      if (saved.ok) return normalizeConfig(await saved.json());
      return local;
    }
  } catch { /* ohne Server bleibt die lokale Anzeige */ }
  return local || defaultConfig();
}

async function saveConfig(value) {
  const payload = clone(value);
  const response = await fetch('/api/config', {
    method: 'PUT',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    let detail = t('Die QNAP hat die Einstellung nicht übernommen.');
    try {
      const data = await response.json();
      if (data.error) detail = data.error;
    } catch { /* Text oben bleibt */ }
    throw new Error(detail);
  }
  const stored = normalizeConfig(await response.json());
  localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
  return stored;
}

async function pullConfig() {
  if (!el('settings-body').hidden) return;
  const response = await fetch('/api/config', {cache: 'no-store'});
  if (!response.ok) return;
  const remote = normalizeConfig(await response.json());
  if (JSON.stringify(remote) === JSON.stringify(config)) return;
  config = remote;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(remote));
  render();
  read();
}

function formatNumber(value, digits) {
  return Number(value).toLocaleString('de-CH', {minimumFractionDigits: digits, maximumFractionDigits: digits});
}

function displayValue(input, value) {
  if (input.kind === 'switch') return onOff(Number(value) >= 0.5);
  return formatNumber(value, input.decimals);
}

function onOff(on) {
  return t(on ? 'Ein' : 'Aus');
}

function currentValue(input) {
  const raw = Number(rawState[input.id]);
  if (Number.isFinite(raw) && input.divisor > 0) return raw / input.divisor;
  const value = Number(state[input.id]);
  return Number.isFinite(value) ? value : NaN;
}

function archivedValue(point, input) {
  const raw = point && point.r ? Number(point.r[input.id]) : NaN;
  if (Number.isFinite(raw) && input.divisor > 0) return raw / input.divisor;
  const value = point && point.v ? Number(point.v[input.id]) : NaN;
  return Number.isFinite(value) ? value : NaN;
}

function menuList(item) {
  const raw = item && Array.isArray(item.menus) ? item.menus : (item && item.menu ? [item.menu] : []);
  const ids = [];
  for (const id of raw) {
    if (typeof id === 'string' && /^[a-z][a-z0-9]{0,15}$/.test(id) && !ids.includes(id)) ids.push(id);
  }
  return ids;
}

function shortProblem(detail) {
  const text = String(detail || 'keine Antwort').replace(/\s+/g, ' ').trim();
  const cut = text.includes(': ') ? text.slice(text.lastIndexOf(': ') + 2) : text;
  return cut.length > 42 ? cut.slice(0, 42) + '…' : cut;
}

function activeMenuId() {
  const hash = location.hash.replace(/^#/, '');
  if (!hash.startsWith('m=')) return '';
  let id = '';
  try { id = decodeURIComponent(hash.slice(2)); } catch { return ''; }
  return (config.menus || []).some((menu) => menu.id === id) ? id : '';
}

function scopedInputs() {
  const menu = activeMenuId();
  if (!menu) return config.inputs.filter((input) => input.home !== false);
  return config.inputs.filter((input) => (input.menus || []).includes(menu));
}

function chartInputs() {
  return scopedInputs().filter((input) => input.chart && !hiddenSeries.has(input.id));
}

function historyNote() {
  const listed = scopedInputs().filter((input) => input.chart);
  if (!listed.length) {
    return t('Keine Kurve aktiv. Unter Anpassen bei einem Eingang „Verlauf“ wählen.');
  }
  if (!chartInputs().length) {
    return t('Alle Verläufe sind ausgeblendet. In der Legende einen Verlauf anklicken.');
  }
  if (!archive.length) {
    return t('Noch keine gespeicherten Messungen. Die QNAP zeichnet im Hintergrund auf, höchstens eine Messung pro Minute, und behält 14 Tage. Die Seite muss dafür nicht offen bleiben.');
  }
  const shown = visibleSamples();
  const range = rangeText();
  const oldest = formatStamp(archive[0].t);
  const newest = formatStamp(archive[archive.length - 1].t);
  if (!shown.length) {
    return t('Im Zeitraum {range} keine Messung. Gespeichert von {oldest} bis {newest}.', {range, oldest, newest});
  }
  return t('{count} Messungen im Zeitraum {range}. Zeiger auf die Kurve zeigt den Wert zu dieser Zeit. Gespeichert von {oldest} bis {newest}. Legende anklicken blendet einen Verlauf ein oder aus.', {count: shown.length, range, oldest, newest});
}

function formatStamp(time) {
  return new Date(time).toLocaleString('de-CH', {day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit'});
}

function formatTick(time, span) {
  const date = new Date(time);
  const clock = date.toLocaleTimeString('de-CH', {hour: '2-digit', minute: '2-digit'});
  if (span < 36 * 60 * 60 * 1000) return clock;
  return date.toLocaleDateString('de-CH', {day: '2-digit', month: '2-digit'}) + ' ' + clock;
}

function xmlText(text) {
  return String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function customWindow() {
  const from = Number(chartFrom) || 0;
  const to = Number(chartTo) || 0;
  if (!from && !to) return null;
  if (from && to && to < from) return null;
  return {from, to: to || Date.now() + 60 * 1000};
}

function rangeText() {
  const custom = customWindow();
  if (!custom) {
    const range = RANGES.find((item) => item.id === rangeId) || RANGES[2];
    return t(range.label);
  }
  const start = custom.from ? formatStamp(custom.from) : '…';
  const end = chartTo ? formatStamp(custom.to) : t('jetzt');
  return start + ' – ' + end;
}

function visibleSamples() {
  const custom = customWindow();
  if (custom) return archive.filter((sample) => sample.t >= custom.from && sample.t <= custom.to);
  const range = RANGES.find((item) => item.id === rangeId) || RANGES[2];
  const from = Date.now() - range.ms;
  return archive.filter((sample) => sample.t >= from);
}

function chartSource() {
  const real = visibleSamples();
  if (real.length) return {points: real, demo: false};
  if (!archive.length) return {points: [{t: Date.now(), v: {...state}, r: {...rawState}}], demo: true};
  return {points: [], demo: false};
}

function thinSamples(points, max) {
  if (points.length <= max) return points;
  const step = Math.ceil(points.length / max);
  const out = [];
  for (let index = 0; index < points.length; index += step) out.push(points[index]);
  const last = points[points.length - 1];
  if (out[out.length - 1] !== last) out.push(last);
  return out;
}

function renderChart() {
  const svg = el('graph');
  const series = chartInputs();
  el('history-note').textContent = historyNote();
  const clearButton = el('clear-history');
  const exportButton = el('export-history');
  if (clearButton) clearButton.disabled = archive.length === 0;
  if (exportButton) exportButton.disabled = archive.length === 0;
  const source = chartSource();
  if (!series.length || !source.points.length) {
    chartModel = null;
    svg.replaceChildren();
    return;
  }
  const points = source.points;
  const drawn = thinSamples(points, 900);
  const w = 700, h = 242, L = 52, R = 12, T = 14, B = 32;
  const values = [];
  for (const point of drawn) {
    for (const input of series) {
      const value = archivedValue(point, input);
      if (Number.isFinite(value)) values.push(value);
    }
  }
  let rawMin = Math.min(...values) - 3;
  let rawMax = Math.max(...values) + 3;
  if (!Number.isFinite(rawMin) || !Number.isFinite(rawMax) || rawMax <= rawMin) {
    rawMin = 0;
    rawMax = 10;
  }
  let min = Math.floor(rawMin / 5) * 5;
  let max = Math.ceil(rawMax / 5) * 5;
  if (max <= min) max = min + 5;
  const t0 = points[0].t;
  const t1 = points[points.length - 1].t;
  const span = Math.max(t1 - t0, 1);
  const xx = (time) => points.length === 1 ? (L + (w - R)) / 2 : L + (w - L - R) * ((time - t0) / span);
  const yy = (value) => T + (h - T - B) * (max - value) / (max - min);
  chartModel = {points, series, xx, yy, w, h, T, B};
  const degree = series.every((input) => input.kind === 'number' && (input.unit === '°C' || input.unit === '°'));
  const parts = [];
  for (let step = 0; step <= 4; step++) {
    const value = min + (max - min) * step / 4;
    const y = yy(value);
    parts.push(`<line class="gridline" x1="${L}" y1="${y}" x2="${w - R}" y2="${y}"/><text class="axis" x="${L - 8}" y="${y + 4}" text-anchor="end">${Math.round(value)}${degree ? '°' : ''}</text>`);
  }
  for (const input of series) {
    const runs = [];
    let run = [];
    let previous = null;
    for (const point of drawn) {
      const value = archivedValue(point, input);
      const gap = previous != null && point.t - previous > DRAW_GAP_MS;
      if (!Number.isFinite(value) || gap) {
        if (run.length) runs.push(run);
        run = [];
      }
      if (Number.isFinite(value)) {
        run.push(point);
        previous = point.t;
      }
    }
    if (run.length) runs.push(run);
    for (const segment of runs) {
      let coords;
      if (segment.length === 1) {
        const x = xx(segment[0].t);
        const y = yy(archivedValue(segment[0], input));
        coords = `${x - 10},${y} ${x + 10},${y}`;
      } else {
        coords = segment.map((point) => `${xx(point.t)},${yy(archivedValue(point, input))}`).join(' ');
      }
      parts.push(`<polyline points="${coords}" fill="none" stroke="${input.color}" stroke-width="${config.view.stroke}" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>`);
    }
  }
  const startLabel = source.demo ? 'Beispiel' : formatTick(t0, span);
  const endLabel = source.demo ? 'Aktuell' : formatTick(t1, span);
  const midLabel = source.demo ? '' : formatTick(t0 + span / 2, span);
  parts.push(`<text class="axis" x="${L}" y="${h - 8}">${xmlText(startLabel)}</text>`);
  if (midLabel) parts.push(`<text class="axis" x="${(L + w - R) / 2}" y="${h - 8}" text-anchor="middle">${xmlText(midLabel)}</text>`);
  parts.push(`<text class="axis" x="${w - R}" y="${h - 8}" text-anchor="end">${xmlText(endLabel)}</text>`);
  parts.push(`<line id="cursor" class="cursorline" x1="0" y1="${T}" x2="0" y2="${h - B}" visibility="hidden"/>`);
  svg.innerHTML = parts.join('');
}

const LAMPS = [
  ['green', 'Grün', '#3ddc97'],
  ['amber', 'Gelb', '#f5c16c'],
  ['red', 'Rot', '#ff5d5d'],
  ['blue', 'Blau', '#62cde5'],
  ['input', 'Eingangsfarbe', '']
];

function lampOf(value) {
  return LAMPS.some(([id]) => id === value) ? value : 'green';
}

function faceOf(input) {
  if (input.face === 'gauge' || input.face === 'switch' || input.face === 'lamp') return input.face;
  return input.kind === 'switch' ? 'switch' : 'number';
}

function lampColor(input) {
  if (lampOf(input.lamp) === 'input') return input.color;
  const found = LAMPS.find(([id]) => id === lampOf(input.lamp));
  return found[2];
}

function signalOn(value, input) {
  const high = Number(value) >= 0.5;
  return Number(input && input.onValue) === 0 ? !high : high;
}

function rawForState(input, on) {
  if (Number(input && input.onValue) === 0) return on ? 0 : 1;
  return on ? 1 : 0;
}

function rangeOf(input) {
  return input.range === 'I' || input.range === 'Q' ? input.range : 'V';
}

let logos = [];

function logoIdOf(input) {
  const value = input && input.logo;
  return typeof value === 'string' && /^[a-z][a-z0-9]{0,15}$/.test(value) ? value : '';
}

function deviceName(input) {
  const id = logoIdOf(input) || (logos[0] && logos[0].id) || '';
  const found = logos.find((item) => item.id === id);
  return found ? found.name : '';
}

function pointLabel(input) {
  const point = rangeOf(input) + input.address;
  if (logos.length < 2) return point;
  const name = deviceName(input);
  return name ? name + ' ' + point : point;
}

function digitalRange(input) {
  return rangeOf(input) !== 'V';
}

function canWrite(input) {
  if (input.writable !== true) return false;
  if (digitalRange(input)) return true;
  const face = faceOf(input);
  return face === 'number' || face === 'gauge';
}

function scaleOf(input) {
  const min = Number(input.scaleMin);
  const max = Number(input.scaleMax);
  const start = Number.isFinite(min) ? min : 0;
  const end = Number.isFinite(max) && max > start ? max : start + 80;
  return {min: start, max: end};
}

const GAUGE_X = 120;
const GAUGE_Y = 96;
const GAUGE_R = 72;
const GAUGE_START = Math.PI * 5 / 4;
const GAUGE_END = -Math.PI / 4;

function polar(radius, angle) {
  return {
    x: GAUGE_X + radius * Math.cos(angle),
    y: GAUGE_Y - radius * Math.sin(angle)
  };
}

function gaugeArc(radius, start, end) {
  const from = polar(radius, start);
  const to = polar(radius, end);
  const large = start - end > Math.PI ? 1 : 0;
  const place = (point) => point.x.toFixed(2) + ' ' + point.y.toFixed(2);
  return 'M ' + place(from) + ' A ' + radius + ' ' + radius + ' 0 ' + large + ' 1 ' + place(to);
}

function gaugeAngle(ratio) {
  const clamped = Math.min(1, Math.max(0, ratio));
  return GAUGE_START + (GAUGE_END - GAUGE_START) * clamped;
}

function optionalZone(value) {
  if (value === null || value === undefined || value === '') return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function gaugeZones(input) {
  const scale = scaleOf(input);
  const span = scale.max - scale.min;
  const pick = (value, fallback) => {
    const number = optionalZone(value);
    return number === null ? fallback : number;
  };
  return {
    min: scale.min,
    max: scale.max,
    green: pick(input.zoneGreen, scale.min),
    blue: pick(input.zoneBlue, scale.min + span * 0.4),
    red: pick(input.zoneRed, scale.min + span * 0.8)
  };
}

function gaugeColorStops(input) {
  const zones = gaugeZones(input);
  return [
    {at: zones.green, color: '#3dcb86'},
    {at: zones.blue, color: '#3d8fd4'},
    {at: zones.red, color: '#e15b5b'}
  ].sort((left, right) => left.at - right.at);
}

function themeColor(name, fallback) {
  const value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return value || fallback;
}

function gaugeZoneColor(input, value) {
  let color = themeColor('--gauge-muted', '#8eabbe');
  for (const stop of gaugeColorStops(input)) {
    if (value >= stop.at) color = stop.color;
  }
  return color;
}

function gaugeBands(input) {
  const zones = gaugeZones(input);
  const span = zones.max - zones.min;
  const ratio = (value) => Math.min(1, Math.max(0, (value - zones.min) / span));
  const stops = gaugeColorStops(input);
  const bands = [];
  if (stops[0].at > zones.min) bands.push([ratio(zones.min), ratio(stops[0].at), themeColor('--gauge-rest', '#2c4658')]);
  stops.forEach((stop, index) => {
    const end = index + 1 < stops.length ? stops[index + 1].at : zones.max;
    bands.push([ratio(stop.at), ratio(end), stop.color]);
  });
  return bands.filter((band) => band[1] - band[0] > 0.001);
}

function svgNode(name, attrs) {
  const node = document.createElementNS('http://www.w3.org/2000/svg', name);
  for (const [key, val] of Object.entries(attrs)) node.setAttribute(key, String(val));
  return node;
}

function gaugeColorAt(input, ratio) {
  const bands = gaugeBands(input);
  for (let index = bands.length - 1; index >= 0; index -= 1) {
    if (ratio >= bands[index][0] - 0.0001) return bands[index][2];
  }
  return themeColor('--gauge-rest', '#2c4658');
}

function gaugeCap(svg, ratio, color) {
  const point = polar(GAUGE_R, gaugeAngle(ratio));
  svg.append(svgNode('circle', {
    cx: point.x.toFixed(2),
    cy: point.y.toFixed(2),
    r: '7',
    fill: color
  }));
}

function appendGauge(parent, input, value, failed) {
  const scale = scaleOf(input);
  const ratio = failed ? 0 : Math.min(1, Math.max(0, (Number(value) - scale.min) / (scale.max - scale.min)));
  const zone = failed ? themeColor('--gauge-muted', '#8eabbe') : gaugeZoneColor(input, Number(value));
  const rest = themeColor('--gauge-rest', '#2c4658');
  const svg = svgNode('svg', {viewBox: '0 0 240 200', class: 'gauge', role: 'img'});
  const label = failed ? input.label + ', kein Wert' : input.label + ' ' + displayValue(input, value) + (input.unit ? ' ' + input.unit : '');
  svg.setAttribute('aria-label', label);
  svg.append(svgNode('path', {
    d: gaugeArc(GAUGE_R, GAUGE_START, GAUGE_END),
    class: 'gauge-track',
    stroke: rest
  }));
  if (!failed && ratio > 0.004) {
    const steps = 72;
    let previous = rest;
    for (let index = 0; index < steps; index += 1) {
      const from = index / steps;
      if (from >= ratio) break;
      const to = Math.min((index + 1) / steps, ratio);
      const color = gaugeColorAt(input, (from + to) / 2);
      if (color === rest) {
        previous = rest;
        continue;
      }
      if (previous !== color) gaugeCap(svg, from, color);
      svg.append(svgNode('path', {
        d: gaugeArc(GAUGE_R, gaugeAngle(from), gaugeAngle(to)),
        class: 'gauge-zone',
        stroke: color
      }));
      previous = color;
    }
    gaugeCap(svg, ratio, gaugeColorAt(input, ratio));
    const dot = polar(GAUGE_R, gaugeAngle(ratio));
    svg.append(svgNode('circle', {
      cx: dot.x.toFixed(2), cy: dot.y.toFixed(2), r: '11',
      fill: zone, opacity: '0.35'
    }));
    svg.append(svgNode('circle', {
      cx: dot.x.toFixed(2), cy: dot.y.toFixed(2), r: '6.5',
      class: 'gauge-dot', fill: '#fff'
    }));
  }
  const reading = svgNode('text', {
    x: String(GAUGE_X), y: String(GAUGE_Y + 8),
    'text-anchor': 'middle', class: 'gauge-read', fill: zone
  });
  const number = svgNode('tspan', {});
  const shownText = failed ? '–' : displayValue(input, value);
  number.textContent = shownText;
  const digits = shownText.length + (input.unit ? 1 : 0);
  reading.setAttribute('font-size', digits >= 7 ? '20' : digits >= 5 ? '24' : '30');
  reading.append(number);
  if (!failed && input.unit) {
    const unit = svgNode('tspan', {class: 'gauge-unit', fill: zone, 'font-size': '14'});
    unit.textContent = input.unit;
    reading.append(unit);
  }
  svg.append(reading);
  parent.append(svg);
}

function inputById(id) {
  if (!id || !config) return null;
  return config.inputs.find((item) => item.id === id) || null;
}

function appendSideSignal(parent, source) {
  const slot = document.createElement('div');
  slot.className = 'side-signal';
  if (!source) {
    parent.append(slot);
    return;
  }
  const failed = Boolean(inputErrors[source.id]);
  const shown = currentValue(source);
  const on = !failed && signalOn(shown, source);
  slot.className = 'side-signal' + (failed ? ' idle' : on ? ' on' : ' off');
  slot.style.setProperty('--lamp', lampColor(source));
  slot.setAttribute('role', 'img');
  slot.setAttribute('aria-label', source.label + (failed ? '' : ', ' + onOff(on)));
  const bulb = document.createElement('span');
  bulb.className = 'bulb';
  const name = document.createElement('div');
  name.className = 'side-name';
  name.textContent = source.label;
  slot.append(bulb, name);
  parent.append(slot);
}

function appendLamp(parent, input, on, failed) {
  const row = document.createElement('div');
  row.className = 'lampface' + (failed ? ' idle' : on ? ' on' : ' off');
  row.style.setProperty('--lamp', lampColor(input));
  row.setAttribute('role', 'img');
  row.setAttribute('aria-label', failed ? 'Leuchte ohne Wert, nur Anzeige' : (on ? 'Leuchte ein, nur Anzeige' : 'Leuchte aus, nur Anzeige'));
  const bulb = document.createElement('span');
  bulb.className = 'bulb';
  const word = document.createElement('div');
  word.className = 'lampword';
  word.textContent = failed ? '–' : onOff(on);
  row.append(bulb, word);
  parent.append(row);
}

function appendSwitch(parent, on, failed) {
  const row = document.createElement('div');
  row.className = 'switchface' + (failed ? ' idle' : on ? ' on' : ' off');
  row.setAttribute('role', 'img');
  row.setAttribute('aria-label', failed ? 'Schalter ohne Wert, nur Anzeige' : (on ? 'Ein, nur Anzeige' : 'Aus, nur Anzeige'));
  const track = document.createElement('div');
  track.className = 'track';
  track.append(document.createElement('span'));
  const word = document.createElement('div');
  word.className = 'switchword';
  word.textContent = failed ? '–' : onOff(on);
  row.append(track, word);
  parent.append(row);
}

function renderCards() {
  const box = el('metrics');
  box.classList.toggle('tint', config.view.colorValues);
  box.replaceChildren();
  const scoped = scopedInputs();
  const visible = scoped.filter((input) => input.card);
  if (!scoped.length) {
    const note = document.createElement('p');
    note.className = 'dim';
    note.textContent = activeMenuId()
      ? t('In diesem Menü ist noch kein Eingang. Unter Anpassen beim Eingang dieses Menü wählen.')
      : t('Im Hauptmenü ist kein Eingang sichtbar. Unter Anpassen „Hauptmenü“ wieder anklicken.');
    box.append(note);
    return;
  }
  if (!visible.length) {
    const note = document.createElement('p');
    note.className = 'dim';
    note.textContent = t('Keine Karten aktiv. Unter Anpassen bei mindestens einem Eingang „Karte“ wählen.');
    box.append(note);
    return;
  }
  for (const input of visible) {
    const card = document.createElement('article');
    card.className = 'card';
    card.style.setProperty('--accent', input.color);
    const label = document.createElement('div');
    label.className = 'label';
    const icon = document.createElement('span');
    icon.className = 'icon';
    icon.textContent = input.icon;
    const name = document.createElement('span');
    name.textContent = input.label;
    label.append(icon, name);
    const failed = Boolean(inputErrors[input.id]);
    const shown = currentValue(input);
    const face = faceOf(input);
    let body;
    const leftSignal = face === 'gauge' ? inputById(input.signalLeft) : null;
    const rightSignal = face === 'gauge' ? inputById(input.signalRight) : null;
    if (face === 'gauge' && (leftSignal || rightSignal)) {
      body = document.createElement('div');
      body.className = 'gauge-row';
      appendSideSignal(body, leftSignal);
      const gauge = document.createElement('div');
      gauge.className = 'gauge-wrap';
      appendGauge(gauge, input, shown, failed);
      body.append(gauge);
      appendSideSignal(body, rightSignal);
    } else if (face === 'gauge') {
      body = document.createElement('div');
      body.className = 'gauge-wrap';
      appendGauge(body, input, shown, failed);
    } else if (face === 'lamp') {
      body = document.createElement('div');
      body.className = 'value';
      appendLamp(body, input, signalOn(shown, input), failed);
    } else if (face === 'switch') {
      body = document.createElement('div');
      body.className = 'value';
      appendSwitch(body, signalOn(shown, input), failed);
    } else {
      body = document.createElement('div');
      body.className = 'value';
      if (!failed && input.kind === 'switch') body.classList.add(signalOn(shown, input) ? 'on' : 'off');
      const number = document.createElement('span');
      number.textContent = failed ? '–' : displayValue(input, shown);
      body.append(number);
      if (!failed && input.kind !== 'switch' && input.unit) {
        const unit = document.createElement('span');
        unit.className = 'unit';
        unit.textContent = input.unit;
        body.append(unit);
      }
    }
    const foot = document.createElement('div');
    foot.className = 'foot';
    const raw = Number(rawState[input.id]);
    const point = pointLabel(input);
    foot.textContent = failed
      ? point + ' · ' + shortProblem(inputErrors[input.id])
      : Number.isFinite(raw)
        ? point + ' · Rohwert ' + formatNumber(raw, Number.isInteger(raw) ? 0 : 1)
        : point;
    card.append(label, body, foot);
    if (canWrite(input)) card.append(digitalRange(input) ? driveForm(input) : setpointForm(input, shown, failed));
    box.append(card);
  }
}

function renderLegend() {
  const legend = el('legend');
  legend.replaceChildren();
  for (const input of scopedInputs().filter((item) => item.chart)) {
    const button = document.createElement('button');
    button.type = 'button';
    button.dataset.series = input.id;
    button.setAttribute('aria-pressed', hiddenSeries.has(input.id) ? 'false' : 'true');
    const swatch = document.createElement('i');
    swatch.className = 'key';
    swatch.style.background = input.color;
    button.append(swatch, document.createTextNode(input.label));
    legend.append(button);
  }
}

function renderComparison() {
  const ist = scopedInputs().find((input) => input.id === config.view.istId);
  const soll = scopedInputs().find((input) => input.id === config.view.sollId);
  const deltaLabel = el('delta-label');
  const difference = el('difference');
  const comparison = el('comparison');
  if (!ist || !soll) {
    deltaLabel.textContent = t('Soll-Ist-Abweichung');
    difference.textContent = '–';
    comparison.textContent = t('Kein Vergleich gewählt');
    comparison.className = '';
    return;
  }
  deltaLabel.textContent = ist.label + ' − ' + soll.label;
  if (inputErrors[ist.id] || inputErrors[soll.id]) {
    difference.textContent = '–';
    comparison.textContent = t('Ein Vergleichswert fehlt');
    comparison.className = 'warn';
    return;
  }
  if (ist.kind === 'switch' || soll.kind === 'switch' || faceOf(ist) === 'lamp' || faceOf(soll) === 'lamp') {
    const same = signalOn(currentValue(ist), ist) === signalOn(currentValue(soll), soll);
    difference.textContent = t(same ? 'Gleich' : 'Unterschiedlich');
    comparison.textContent = t(same ? 'Gleiche Schaltstellung' : 'Abweichende Schaltstellung');
    comparison.className = same ? 'positive' : 'warn';
    return;
  }
  const delta = Number(currentValue(ist)) - Number(currentValue(soll));
  const digits = Math.max(ist.decimals, soll.decimals);
  const unit = ist.unit ? ' ' + ist.unit : '';
  difference.textContent = (delta > 0 ? '+' : '') + formatNumber(delta, digits) + unit;
  const tolerance = config.view.tolerance;
  if (Math.abs(delta) <= tolerance) {
    comparison.textContent = t('Nahe am Sollwert');
    comparison.className = 'positive';
  } else if (delta > tolerance) {
    comparison.textContent = t('Über Sollwert');
    comparison.className = 'warn';
  } else {
    comparison.textContent = t('Unter Sollwert');
    comparison.className = 'warn';
  }
}

function renderMenuNav() {
  const box = el('menu-links');
  if (!box) return;
  const current = activeMenuId();
  const home = document.querySelector('.nav a[href="/"]');
  if (home) {
    if (current) home.removeAttribute('aria-current');
    else home.setAttribute('aria-current', 'page');
  }
  box.replaceChildren();
  for (const menu of config.menus || []) {
    const link = document.createElement('a');
    link.href = '#m=' + encodeURIComponent(menu.id);
    link.textContent = menu.name;
    if (menu.id === current) link.setAttribute('aria-current', 'page');
    box.append(link);
  }
}

function renderTexts() {
  const menu = (config.menus || []).find((item) => item.id === activeMenuId());
  el('page-title').textContent = menu ? menu.name : config.view.title;
  el('page-subtitle').textContent = config.view.subtitle;
  document.title = (menu ? menu.name : config.view.title) + ' · LOGO! 9';
  const addresses = scopedInputs().map((input) => pointLabel(input)).join(' / ');
  const writes = scopedInputs().some((input) => canWrite(input));
  el('page-footer').textContent = t(writes
    ? 'Persönliche Heizungsübersicht · LOGO {addresses} · Schalten nur nach Bestätigung'
    : 'Persönliche Heizungsübersicht · LOGO {addresses} · Keine Steuerausgänge', {addresses});
}

function render() {
  renderMenuNav();
  renderTexts();
  renderCards();
  renderRangeButtons();
  renderChart();
  renderLegend();
  renderComparison();
  setAutoUi(interval !== null);
}

function setStatus(type, message) {
  mode = type;
  el('dot').className = 'dot' + (type === 'live' ? ' live' : type === 'error' ? ' error' : '');
  el('connection').textContent = message;
  el('history-note').textContent = historyNote();
}

function structureKey(inputs) {
  return inputs.map((input) => [input.id, logoIdOf(input), rangeOf(input), input.address, input.divisor, input.kind].join(':')).join('|');
}

function applyState(next, resetDemo) {
  const previousConfig = config;
  const previous = state;
  const oldById = new Map(previousConfig.inputs.map((input) => [input.id, input]));
  config = next;
  if (resetDemo || (mode === 'demo' && structureKey(previousConfig.inputs) === structureKey(next.inputs))) {
    rawState = {};
    state = Object.fromEntries(config.inputs.map((input) => [input.id, input.demo]));
    return;
  }
  if (structureKey(previousConfig.inputs) === structureKey(next.inputs)) return;
  state = {};
  for (const input of config.inputs) {
    const old = oldById.get(input.id);
    const sameSource = old && old.address === input.address && old.kind === input.kind;
    const knownRaw = Number(rawState[input.id]);
    if (sameSource && Number.isFinite(knownRaw)) {
      state[input.id] = knownRaw / input.divisor;
      continue;
    }
    const previousValue = Number(previous[input.id]);
    if (sameSource && Number.isFinite(previousValue)) {
      if (old.divisor !== input.divisor && old.divisor > 0) {
        const recovered = previousValue * old.divisor;
        rawState[input.id] = recovered;
        state[input.id] = recovered / input.divisor;
      } else {
        state[input.id] = previousValue;
      }
      continue;
    }
    delete rawState[input.id];
    state[input.id] = input.demo;
  }
  rescaleArchive(oldById);
}

function rescaleArchive(oldById) {
  let changed = false;
  for (const input of config.inputs) {
    const old = oldById.get(input.id);
    if (!old || old.divisor === input.divisor || old.address !== input.address || !(old.divisor > 0)) continue;
    for (const sample of archive) {
      const knownRaw = sample.r ? Number(sample.r[input.id]) : NaN;
      const recovered = Number.isFinite(knownRaw) ? knownRaw : Number(sample.v[input.id]) * old.divisor;
      if (!Number.isFinite(recovered)) continue;
      if (!sample.r) sample.r = {};
      sample.r[input.id] = recovered;
      sample.v[input.id] = Math.round(recovered / input.divisor * 1000) / 1000;
      changed = true;
    }
  }
  if (!changed) return;
  archiveDirty = true;
  if (archiveTimer) clearTimeout(archiveTimer);
  archiveTimer = setTimeout(flushArchive, 1500);
}

function parseReading(text) {
  const trimmed = String(text).trim();
  let value;
  try {
    const obj = JSON.parse(trimmed);
    if (typeof obj === 'number') value = obj;
    else if (typeof obj === 'string') value = Number(obj);
    else if (obj && typeof obj === 'object' && typeof obj.value === 'number') value = obj.value;
    else value = Number(trimmed);
  } catch {
    value = Number(trimmed);
  }
  if (!Number.isFinite(value) || Math.abs(value) > 50000) throw new Error('Unbekanntes API-Antwortformat');
  return value;
}

function inExtension() {
  return true;
}

function outsideExtensionMessage() {
  return 'Bitte den Heizungsmonitor über die Adresse deines Container-Servers öffnen. Die Datei dashboard.html nicht direkt öffnen.';
}

function readingFromBody(body, address) {
  const text = String(body).replace(/^\uFEFF/, '').replace(/\u0000/g, '').trim();
  if (!text) throw new Error('Leere Antwort von vi' + address);
  const typed = text.match(/^\s*(.*?)\s*\(([a-zA-Z]{1,4})\)\s*$/);
  if (Number.isInteger(address)) readingSuffix[address] = typed ? typed[2] : '';
  const cleaned = (typed ? typed[1] : text).replace(/^["']|["']$/g, '').trim();
  const direct = cleaned.replace(',', '.');
  if (/^[-+]?\d+(?:\.\d+)?$/.test(direct)) return direct;
  if (cleaned.length <= 40) {
    const match = cleaned.match(/^[-+]?\d+(?:[.,]\d+)?/);
    const rest = match ? cleaned.slice(match[0].length).trim() : cleaned;
    if (match && rest.length <= 8) return match[0].replace(',', '.');
    if (/^(?:0x)?[0-9a-fA-F]+$/i.test(cleaned) && /[a-fA-F]/.test(cleaned)) {
      return String(parseInt(cleaned.replace(/^0x/i, ''), 16));
    }
  }
  const preview = text.replace(/\s+/g, ' ').slice(0, 40);
  throw new Error('Unerwartete API-Antwort bei vi' + address + ': ' + preview);
}

function setpointForm(input, shown, failed) {
  const scale = scaleOf(input);
  const form = document.createElement('form');
  form.className = 'setpoint';
  const field = document.createElement('input');
  field.type = 'text';
  field.inputMode = 'decimal';
  field.setAttribute('aria-label', t('Sollwert') + ' ' + input.label);
  field.value = failed || !Number.isFinite(shown) ? '' : Number(shown).toFixed(input.decimals);
  const button = document.createElement('button');
  button.type = 'submit';
  button.className = 'small';
  button.textContent = t('Setzen');
  const range = document.createElement('span');
  range.className = 'sethint';
  range.textContent = formatNumber(scale.min, 0) + '…' + formatNumber(scale.max, 0);
  form.append(field, button, range);
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    writeSetpoint(input, parseLooseNumber(field.value));
  });
  form.title = 'Erlaubter Bereich ' + formatNumber(scale.min, 0) + ' bis ' + formatNumber(scale.max, 0);
  return form;
}

function setpointBodies(raw, suffix) {
  const plain = String(raw);
  const tagged = (suffix || 'i');
  const withType = plain + '(' + tagged + ')';
  return suffix ? [withType, plain] : [plain, withType];
}

function pointUrl(input) {
  const logo = logoIdOf(input);
  const prefix = logo ? '/' + logo : '';
  return digitalRange(input)
    ? '/api/io' + prefix + '/' + rangeOf(input) + '/' + input.address
    : '/api/vi' + prefix + '/' + input.address;
}

async function putOnce(input, bodyText) {
  const controller = new AbortController();
  const stop = setTimeout(() => controller.abort(), 12000);
  const point = pointLabel(input);
  try {
    const response = await fetch(pointUrl(input), {
      method: 'PUT',
      cache: 'no-store',
      headers: {Accept: 'text/plain, application/json', 'Content-Type': 'text/plain'},
      body: bodyText,
      signal: controller.signal
    });
    const body = await response.text();
    if (!response.ok) {
      const preview = body.replace(/\s+/g, ' ').trim().slice(0, 40);
      if (response.status === 401 || response.status === 403) {
        throw new Error('Anmeldung erforderlich (HTTP ' + response.status + ') für ' + point);
      }
      throw new Error('Serverfehler HTTP ' + response.status + ' bei ' + point + (preview ? ': ' + preview : ''));
    }
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('Zeitüberschreitung bei ' + point);
    throw error;
  } finally {
    clearTimeout(stop);
  }
}

async function putAddress(input, raw, bodyText) {
  const address = input.address;
  const digital = digitalRange(input);
  if (!digital && (!Number.isInteger(address) || address < 0 || address > 65535)) {
    throw new Error('Ungültige Adresse ' + pointLabel(input));
  }
  if (digital && (!Number.isInteger(address) || address < 1 || address > 128)) {
    throw new Error('Ungültige Adresse ' + pointLabel(input));
  }
  if (!Number.isInteger(raw) || raw < -32768 || raw > 32767) {
    throw new Error('Rohwert ausserhalb des Int-Bereichs');
  }
  await putOnce(input, bodyText);
}

async function writeSetpoint(input, value) {
  if (!canWrite(input)) return;
  if (writing || reading) {
    el('error').textContent = t('Bitte warten, ein Abruf oder Schreibvorgang läuft.');
    return;
  }
  if (!inExtension()) {
    setStatus('error', 'Direkt geöffnet');
    el('error').textContent = outsideExtensionMessage();
    return;
  }
  const scale = scaleOf(input);
  if (!Number.isFinite(value) || value < scale.min || value > scale.max) {
    el('error').textContent = t('Sollwert von „{label}“ muss zwischen {min} und {max} liegen.', {label: input.label, min: formatNumber(scale.min, 0), max: formatNumber(scale.max, 0)});
    return;
  }
  const raw = Math.round(value * input.divisor);
  if (!Number.isInteger(raw) || raw < -32768 || raw > 32767) {
    el('error').textContent = t('Der Rohwert von „{label}“ liegt ausserhalb des Int-Bereichs.', {label: input.label});
    return;
  }
  const stored = raw / input.divisor;
  const unit = input.unit ? ' ' + input.unit : '';
  const question = 'Sollwert „' + input.label + '“ auf ' + formatNumber(stored, input.decimals) + unit + ' setzen? Das schreibt den Rohwert ' + raw + ' an ' + pointLabel(input) + '.';
  if (!window.confirm(question)) {
    el('error').textContent = t('Setzen abgebrochen.');
    return;
  }
  writing = true;
  const suffix = typeof readingSuffix[input.address] === 'string' ? readingSuffix[input.address] : '';
  let seen = NaN;
  try {
    let lastError = null;
    for (const bodyText of setpointBodies(raw, suffix)) {
      try {
        await putAddress(input, raw, bodyText);
      } catch (error) {
        lastError = error;
        if (/Failed to fetch|NetworkError|network/i.test(String(error.message || error))) break;
        continue;
      }
      await new Promise((resolve) => setTimeout(resolve, 400));
      const ok = await read();
      if (!ok) {
        lastError = new Error('Der anschliessende Abruf ist fehlgeschlagen');
        continue;
      }
      seen = Number(rawState[input.id]);
      if (seen === raw) {
        el('error').textContent = t('Sollwert übernommen. {point} steht auf Rohwert {raw}.', {point: pointLabel(input), raw});
        return;
      }
      lastError = null;
    }
    if (lastError) throw lastError;
    const shownRaw = Number.isFinite(seen) ? String(seen) : 'keinen Wert';
    el('error').textContent = pointLabel(input) + ' zeigt nach dem Schreiben Rohwert ' + shownRaw + ' statt ' + raw + '. Die LOGO! schreibt diese Adresse im Programm vermutlich selbst. Zum Ändern die Variable nehmen, die das Programm als Sollwert einliest.';
  } catch (error) {
    setStatus('error', 'Sollwert nicht geschrieben');
    el('error').textContent = t('Schreiben fehlgeschlagen: {error}', {error: error.message || error});
  } finally {
    writing = false;
  }
}

function driveForm(input) {
  const form = document.createElement('form');
  form.className = 'setpoint';
  for (const [on, label] of [[true, t('Ein')], [false, t('Aus')]]) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'small';
    button.textContent = label;
    button.addEventListener('click', () => writeDigital(input, on));
    form.append(button);
  }
  return form;
}

async function writeDigital(input, on) {
  if (!canWrite(input) || !digitalRange(input)) return;
  if (writing || reading) {
    el('error').textContent = t('Bitte warten, ein Abruf oder Schreibvorgang läuft.');
    return;
  }
  const raw = rawForState(input, on);
  const point = pointLabel(input);
  const stateText = onOff(on);
  const question = rangeOf(input) === 'Q'
    ? t('Ausgang „{label}“ auf {state} schalten? Das schreibt {point} an der LOGO.', {label: input.label, state: stateText, point})
    : t('Eingang „{label}“ auf {state} setzen? Das schreibt {point} an der LOGO. Die Klemme oder das Programm kann den Wert sofort wieder überschreiben.', {label: input.label, state: stateText, point});
  if (!window.confirm(question)) {
    el('error').textContent = t('Schalten abgebrochen.');
    return;
  }
  writing = true;
  try {
    await putAddress(input, raw, String(raw));
    await new Promise((resolve) => setTimeout(resolve, 400));
    const ok = await read();
    if (!ok) throw new Error(t('Der anschliessende Abruf ist fehlgeschlagen'));
    const seen = Number(rawState[input.id]);
    if (seen === raw) {
      el('error').textContent = t('{point} steht auf {state}.', {point, state: stateText});
      return;
    }
    const seenText = seen === 0 || seen === 1 ? (signalOn(seen, input) ? t('Ein') : t('Aus')) : t('keinen Wert');
    el('error').textContent = t('{point} zeigt nach dem Schreiben {seen} statt {state}. Die LOGO schreibt diesen Punkt im Programm vermutlich selbst.', {point, seen: seenText, state: stateText});
  } catch (error) {
    setStatus('error', t('Nicht geschaltet'));
    el('error').textContent = t('Schalten fehlgeschlagen: {error}', {error: error.message || error});
  } finally {
    writing = false;
  }
}

async function fetchAddress(input) {
  const address = input.address;
  const digital = digitalRange(input);
  const point = pointLabel(input);
  if (!digital && (!Number.isInteger(address) || address < 0 || address > 65535)) {
    throw new Error('Ungültige Adresse ' + point);
  }
  if (digital && (!Number.isInteger(address) || address < 1 || address > 128)) {
    throw new Error('Ungültige Adresse ' + point);
  }
  const controller = new AbortController();
  const stop = setTimeout(() => controller.abort(), 20000);
  try {
    const response = await fetch(pointUrl(input), {
      method: 'GET',
      cache: 'no-store',
      headers: {Accept: 'text/plain, application/json'},
      signal: controller.signal
    });
    const body = await response.text();
    if (!response.ok) {
      const full = body.replace(/\s+/g, ' ').trim();
      if (response.status === 401) throw new Error('Anmeldung erforderlich für ' + point);
      if (response.status === 403 || response.status === 502) throw new Error(full || ('Abruf von ' + point + ' fehlgeschlagen'));
      const preview = full.slice(0, 80);
      throw new Error('Serverfehler HTTP ' + response.status + ' bei ' + point + (preview ? ': ' + preview : ''));
    }
    return readingFromBody(body, address);
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('Zeitüberschreitung bei ' + point);
    throw error;
  } finally {
    clearTimeout(stop);
  }
}

async function readInputs() {
  const direct = [];
  for (const input of config.inputs) {
    try {
      direct.push({id: input.id, ok: true, value: await fetchAddress(input)});
    } catch (error) {
      direct.push({id: input.id, ok: false, error: String(error.message || error)});
    }
  }
  return {ok: direct.some((entry) => entry.ok), values: Object.fromEntries(direct.filter((entry) => entry.ok).map((entry) => [entry.id, entry.value])), errors: direct.filter((entry) => !entry.ok).map((entry) => ({id: entry.id, error: entry.error}))};
}

async function read() {
  if (reading) return false;
  reading = true;
  el('load').disabled = true;
  el('error').textContent = '';
  try {
    if (!inExtension()) throw new Error(outsideExtensionMessage());
    const result = await readInputs();
    if (!result || !result.ok) {
      const detail = Array.isArray(result?.errors) && result.errors.length
        ? result.errors.map((item) => item.error).filter((text, index, list) => list.indexOf(text) === index).join(' · ')
        : t(result?.error || 'Keine Antwort von der LOGO');
      throw new Error(detail);
    }
    const values = result.values || {};
    const next = {};
    const problems = [];
    inputErrors = {};
    let readCount = 0;
    for (const input of config.inputs) {
      const serverError = Array.isArray(result.errors) ? result.errors.find((item) => item.id === input.id) : null;
      if (!(input.id in values)) {
        const detail = t(serverError?.error) || t('Die QNAP hat {point} nicht abgefragt. Seite neu laden.', {point: pointLabel(input)});
        inputErrors[input.id] = detail;
        problems.push(input.label + ' (' + pointLabel(input) + '): ' + detail);
        next[input.id] = Object.prototype.hasOwnProperty.call(state, input.id) ? state[input.id] : input.demo;
        continue;
      }
      try {
        const raw = parseReading(values[input.id]);
        const scaled = raw / input.divisor;
        if (!Number.isFinite(scaled) || Math.abs(scaled) > 50000) throw new Error('Unbekanntes API-Antwortformat');
        rawState[input.id] = raw;
        next[input.id] = scaled;
        readCount += 1;
      } catch (error) {
        inputErrors[input.id] = error.message;
        problems.push(input.label + ' (' + pointLabel(input) + '): ' + error.message);
        next[input.id] = Object.prototype.hasOwnProperty.call(state, input.id) ? state[input.id] : input.demo;
      }
    }
    if (!readCount) throw new Error(problems.join(' · ') || 'Keine Werte');
    state = next;
    setStatus('live', problems.length ? t('Live · ein Eingang fehlt') : t('Live · nur lesend'));
    el('last').textContent = new Date().toLocaleTimeString('de-CH', {hour: '2-digit', minute: '2-digit', second: '2-digit'});
    el('error').textContent = problems.length
      ? 'Verbunden. Nicht gelesen: ' + problems.join(' · ') + '. Adresse dieses Eingangs prüfen oder ihn entfernen. Die übrigen Werte laufen weiter.'
      : '';
    render();
    return true;
  } catch (error) {
    setStatus('error', t('Keine Live-Verbindung'));
    el('error').textContent = t('Abruf fehlgeschlagen: {error}', {error: t(error.message)});
    return false;
  } finally {
    reading = false;
    el('load').disabled = false;
  }
}

function clearAutoTimer() {
  if (interval) clearInterval(interval);
  interval = null;
}

function setAutoUi(active) {
  el('auto').textContent = active ? t('Auto: {seconds} s', {seconds: config.view.intervalSec}) : t('Auto: Aus');
  el('auto').setAttribute('aria-pressed', active ? 'true' : 'false');
}

function startAuto() {
  clearAutoTimer();
  interval = setInterval(async () => {
    const success = await read();
    if (!success) {
      clearAutoTimer();
      setAutoUi(false);
    }
  }, config.view.intervalSec * 1000);
  setAutoUi(true);
}

function stopAuto() {
  clearAutoTimer();
  setAutoUi(false);
}

function parseLooseNumber(value) {
  const text = String(value).trim().replace(',', '.');
  return text === '' ? NaN : Number(text);
}

function setSettingsMessage(text, ok) {
  const node = el('settings-msg');
  node.textContent = text;
  node.className = ok ? 'okline' : 'errorline';
}

function makeField(caption, control, className) {
  const label = document.createElement('label');
  label.className = className || 'field';
  label.append(document.createTextNode(caption), control);
  return label;
}

function draftMenus() {
  const list = el('menu-list');
  if (!list) return [];
  return [...list.querySelectorAll('[data-menu]')].map((row) => ({
    id: row.dataset.menu,
    name: row.querySelector('input').value.trim().slice(0, 40)
  })).filter((menu) => menu.name);
}

function selectedMenuIds(box) {
  if (!box) return [];
  return [...box.querySelectorAll('button[data-menu][aria-pressed="true"]')].map((button) => button.dataset.menu);
}

function homePressed(box) {
  if (!box) return true;
  const button = box.querySelector('button[data-place="home"]');
  return button ? button.getAttribute('aria-pressed') === 'true' : true;
}

function refreshMenuSelects() {
  const editor = el('input-editor');
  if (!editor) return;
  for (const box of editor.querySelectorAll('[data-field="menus"]')) fillMenuPicks(box);
}

function fillMenuPicks(box, current, home) {
  const chosen = new Set(current == null ? selectedMenuIds(box) : current);
  const showHome = home == null ? homePressed(box) : home !== false;
  box.replaceChildren();
  const homeButton = document.createElement('button');
  homeButton.type = 'button';
  homeButton.className = 'small';
  homeButton.dataset.place = 'home';
  homeButton.textContent = t('Hauptmenü');
  homeButton.setAttribute('aria-pressed', showHome ? 'true' : 'false');
  homeButton.addEventListener('click', () => {
    const next = homeButton.getAttribute('aria-pressed') !== 'true';
    homeButton.setAttribute('aria-pressed', next ? 'true' : 'false');
  });
  box.append(homeButton);
  for (const menu of draftMenus()) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'small';
    button.dataset.menu = menu.id;
    button.textContent = menu.name;
    const on = chosen.has(menu.id);
    button.setAttribute('aria-pressed', on ? 'true' : 'false');
    button.addEventListener('click', () => {
      const next = button.getAttribute('aria-pressed') !== 'true';
      button.setAttribute('aria-pressed', next ? 'true' : 'false');
    });
    box.append(button);
  }
}

function addMenuRow(menu) {
  const list = el('menu-list');
  if (!list || list.children.length >= 8) return;
  if ([...list.querySelectorAll('[data-menu]')].some((row) => row.dataset.menu === menu.id)) return;
  const row = document.createElement('div');
  row.className = 'menu-row';
  row.dataset.menu = menu.id;
  const input = document.createElement('input');
  input.maxLength = 40;
  input.value = menu.name;
  input.setAttribute('aria-label', t('Menü'));
  input.addEventListener('input', refreshMenuSelects);
  const remove = document.createElement('button');
  remove.type = 'button';
  remove.className = 'secondary';
  remove.textContent = t('Entfernen');
  remove.addEventListener('click', () => {
    row.remove();
    refreshMenuSelects();
  });
  row.append(input, remove);
  list.append(row);
  refreshMenuSelects();
}

function newMenuId() {
  const used = new Set([...el('menu-list').querySelectorAll('[data-menu]')].map((row) => row.dataset.menu));
  let id = '';
  do {
    id = 'm' + Math.random().toString(36).slice(2, 8);
  } while (used.has(id) || !/^[a-z][a-z0-9]{0,15}$/.test(id));
  return id;
}

function fillMenuList(menus) {
  const list = el('menu-list');
  if (!list) return;
  list.replaceChildren();
  for (const menu of menus || []) addMenuRow(menu);
}

function appendCard(input) {
  const card = document.createElement('article');
  card.className = 'editor-card';
  card.dataset.id = input.id;

  const color = document.createElement('input');
  color.type = 'color';
  color.dataset.field = 'color';
  color.value = normalizeColor(input.color) || '#62cde5';

  const name = document.createElement('input');
  name.dataset.field = 'label';
  name.maxLength = 40;
  name.value = input.label;
  name.autocomplete = 'off';
  name.setAttribute('aria-label', 'Name');
  name.addEventListener('input', () => updateRoleLabel(input.id, name.value));

  const presetFilter = document.createElement('input');
  presetFilter.type = 'search';
  presetFilter.placeholder = t('Vorlage filtern: Licht, Schalter, Pumpe');
  presetFilter.autocomplete = 'off';
  presetFilter.setAttribute('aria-label', t('Vorlage filtern'));
  const presetList = document.createElement('div');
  presetList.className = 'preset-list';
  presetList.hidden = true;
  function renderPresets() {
    const query = presetFilter.value.trim().toLocaleLowerCase(typeof hmLang === 'function' ? hmLang() : 'de');
    const matches = NAME_PRESETS.filter((preset) => presetMatches(preset, query));
    presetList.replaceChildren();
    presetList.hidden = matches.length === 0;
    for (const preset of matches) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'preset';
      button.textContent = t(preset.name) + ' · ' + t(preset.group);
      button.addEventListener('mousedown', (event) => {
        event.preventDefault();
        name.value = t(preset.name);
        name.dispatchEvent(new Event('input'));
        applyNamePreset(card, preset);
        presetFilter.value = '';
        presetList.hidden = true;
      });
      presetList.append(button);
    }
  }
  presetFilter.addEventListener('focus', renderPresets);
  presetFilter.addEventListener('input', renderPresets);
  presetFilter.addEventListener('blur', () => setTimeout(() => { presetList.hidden = true; }, 150));

  const nameField = document.createElement('div');
  nameField.className = 'field grow';
  const nameCaption = document.createElement('span');
  nameCaption.textContent = t('Name');
  nameField.append(nameCaption, name, presetFilter, presetList);

  const top = document.createElement('div');
  top.className = 'editor-top';
  top.append(
    makeField(t('Farbe'), color, 'field narrow'),
    nameField,
    makeField(t('Symbol'), symbolSelect(input.icon), 'field symbol')
  );

  const range = document.createElement('select');
  range.dataset.field = 'range';
  for (const [value, text] of [['V', t('V Variable')], ['I', t('I Eingang')], ['Q', t('Q Ausgang')]]) {
    const option = document.createElement('option');
    option.value = value;
    option.textContent = text;
    range.append(option);
  }
  range.value = rangeOf(input);

  const address = document.createElement('input');
  address.dataset.field = 'address';
  address.inputMode = 'numeric';
  address.value = String(input.address);

  const unit = document.createElement('input');
  unit.dataset.field = 'unit';
  unit.maxLength = 8;
  unit.value = input.unit;

  const divisor = document.createElement('input');
  divisor.dataset.field = 'divisor';
  divisor.inputMode = 'decimal';
  divisor.value = String(input.divisor);

  const decimals = document.createElement('input');
  decimals.dataset.field = 'decimals';
  decimals.inputMode = 'numeric';
  decimals.value = String(input.decimals);

  const demo = document.createElement('input');
  demo.dataset.field = 'demo';
  demo.inputMode = 'decimal';
  demo.value = String(input.demo);

  const face = document.createElement('select');
  face.dataset.field = 'face';
  face.append(new Option(t('Zahl'), 'number'), new Option(t('Tacho'), 'gauge'), new Option(t('Schalter'), 'switch'), new Option(t('Leuchte'), 'lamp'));
  face.value = input.face === 'gauge' || input.face === 'switch' || input.face === 'lamp' ? input.face : (input.kind === 'switch' ? 'switch' : 'number');

  const lamp = document.createElement('select');
  lamp.dataset.field = 'lamp';
  for (const [id, name] of LAMPS) lamp.append(new Option(t(name), id));
  lamp.value = lampOf(input.lamp);

  const active = document.createElement('select');
  active.dataset.field = 'onValue';
  active.append(new Option('1', '1'), new Option('0', '0'));
  active.value = Number(input.onValue) === 0 ? '0' : '1';

  const scaleMin = document.createElement('input');
  scaleMin.dataset.field = 'scaleMin';
  scaleMin.inputMode = 'decimal';
  scaleMin.value = String(Number.isFinite(Number(input.scaleMin)) ? input.scaleMin : 0);

  const scaleMax = document.createElement('input');
  scaleMax.dataset.field = 'scaleMax';
  scaleMax.inputMode = 'decimal';
  scaleMax.value = String(Number.isFinite(Number(input.scaleMax)) ? input.scaleMax : 80);

  const zones = gaugeZones(input);
  const zoneGreen = document.createElement('input');
  zoneGreen.dataset.field = 'zoneGreen';
  zoneGreen.inputMode = 'decimal';
  zoneGreen.value = String(zones.green);
  const zoneBlue = document.createElement('input');
  zoneBlue.dataset.field = 'zoneBlue';
  zoneBlue.inputMode = 'decimal';
  zoneBlue.value = String(zones.blue);
  const zoneRed = document.createElement('input');
  zoneRed.dataset.field = 'zoneRed';
  zoneRed.inputMode = 'decimal';
  zoneRed.value = String(zones.red);

  const logoSelect = document.createElement('select');
  logoSelect.dataset.field = 'logo';
  fillLogoSelect(logoSelect, input.logo);

  const places = document.createElement('div');
  places.className = 'menu-picks';
  places.dataset.field = 'menus';
  fillMenuPicks(places, menuList(input), input.home !== false);

  const leftSignal = signalSelect('signalLeft', input.signalLeft);
  const rightSignal = signalSelect('signalRight', input.signalRight);

  const grid = document.createElement('div');
  grid.className = 'editor-grid';
  grid.append(
    makeField(t('Sichtbar in'), places, 'field places'),
    makeField(t('Gerät'), logoSelect),
    makeField(t('Bereich'), range),
    makeField(t('Adresse'), address),
    makeField(t('Einheit'), unit),
    makeField(t('Teiler'), divisor),
    makeField(t('Nachkommastellen'), decimals),
    makeField(t('Demo-Wert'), demo),
    makeField(t('Darstellung'), face),
    makeField(t('Signal'), lamp),
    makeField(t('Grün bei'), active),
    makeField(t('Tacho von'), scaleMin),
    makeField(t('Tacho bis'), scaleMax),
    makeField(t('Grün ab'), zoneGreen),
    makeField(t('Blau ab'), zoneBlue),
    makeField(t('Rot ab'), zoneRed),
    makeField(t('Signal links'), leftSignal),
    makeField(t('Signal rechts'), rightSignal)
  );

  const cardCheck = document.createElement('input');
  cardCheck.type = 'checkbox';
  cardCheck.dataset.field = 'card';
  cardCheck.checked = input.card !== false;
  const chartCheck = document.createElement('input');
  chartCheck.type = 'checkbox';
  chartCheck.dataset.field = 'chart';
  chartCheck.checked = input.chart !== false;
  const cardLabel = document.createElement('label');
  cardLabel.className = 'checkline';
  cardLabel.append(cardCheck, document.createTextNode(t('Karte')));
  const chartLabel = document.createElement('label');
  chartLabel.className = 'checkline';
  chartLabel.append(chartCheck, document.createTextNode(t('Verlauf')));
  const writeCheck = document.createElement('input');
  writeCheck.type = 'checkbox';
  writeCheck.dataset.field = 'writable';
  writeCheck.checked = input.writable === true && (digitalRange(input) || (input.face !== 'switch' && input.face !== 'lamp'));
  const writeText = document.createTextNode(t('Sollwert schreiben'));
  const writeLabel = document.createElement('label');
  writeLabel.className = 'checkline';
  writeLabel.append(writeCheck, writeText);
  function syncWriteCheck() {
    const digital = range.value === 'I' || range.value === 'Q';
    const blocked = !digital && (face.value === 'switch' || face.value === 'lamp');
    writeCheck.disabled = blocked;
    if (blocked) writeCheck.checked = false;
    writeText.textContent = digital ? t('Ansteuern') : t('Sollwert schreiben');
  }
  face.addEventListener('change', syncWriteCheck);
  range.addEventListener('change', syncWriteCheck);
  function syncActive() {
    const field = active.closest('.field');
    if (field) field.hidden = face.value !== 'switch' && face.value !== 'lamp';
  }
  function syncSides() {
    const show = face.value === 'gauge';
    for (const select of [leftSignal, rightSignal]) {
      const box = select.closest('.field');
      if (box) box.hidden = !show;
    }
  }
  face.addEventListener('change', syncActive);
  face.addEventListener('change', syncSides);
  syncActive();
  syncSides();
  syncWriteCheck();

  const up = document.createElement('button');
  up.type = 'button';
  up.className = 'small';
  up.dataset.action = 'up';
  up.textContent = t('Nach oben');
  const down = document.createElement('button');
  down.type = 'button';
  down.className = 'small';
  down.dataset.action = 'down';
  down.textContent = t('Nach unten');
  const remove = document.createElement('button');
  remove.type = 'button';
  remove.className = 'small danger';
  remove.dataset.action = 'remove';
  remove.textContent = t('Entfernen');

  const actions = document.createElement('div');
  actions.className = 'editor-actions';
  actions.append(cardLabel, chartLabel, writeLabel, up, down, remove);
  card.append(top, grid, actions);
  el('input-editor').append(card);
}

function updateRoleLabel(id, label) {
  const text = label.trim() || 'Eingang';
  const selects = [el('ist-select'), el('soll-select'), ...el('input-editor').querySelectorAll('[data-field="signalLeft"], [data-field="signalRight"]')];
  for (const select of selects) {
    const option = [...select.options].find((item) => item.value === id);
    if (option) option.textContent = text;
  }
}

function signalSelect(field, chosen) {
  const select = document.createElement('select');
  select.dataset.field = field;
  select.dataset.chosen = chosen || '';
  select.addEventListener('change', () => { select.dataset.chosen = select.value; });
  return select;
}

function refreshRoleOptions() {
  const cards = [...el('input-editor').querySelectorAll('.editor-card')];
  for (const select of [el('ist-select'), el('soll-select')]) {
    const current = select.value;
    select.replaceChildren(new Option(t('Kein Vergleich'), ''));
    for (const card of cards) {
      const label = card.querySelector('[data-field="label"]').value.trim() || 'Eingang';
      select.append(new Option(label, card.dataset.id));
    }
    select.value = [...select.options].some((option) => option.value === current) ? current : '';
  }
  for (const select of el('input-editor').querySelectorAll('[data-field="signalLeft"], [data-field="signalRight"]')) {
    const card = select.closest('.editor-card');
    const chosen = select.dataset.chosen || '';
    select.replaceChildren(new Option(t('Kein Signal'), ''));
    for (const other of cards) {
      if (other === card) continue;
      const label = other.querySelector('[data-field="label"]').value.trim() || 'Eingang';
      select.append(new Option(label, other.dataset.id));
    }
    select.value = [...select.options].some((option) => option.value === chosen) ? chosen : '';
    select.dataset.chosen = select.value;
  }
  const full = cards.length >= INPUT_CAP;
  el('add-input').disabled = full;
  const limit = el('input-limit');
  if (limit) limit.hidden = !full;
  const alone = cards.length <= 1;
  for (const button of el('input-editor').querySelectorAll('[data-action="remove"]')) button.disabled = alone;
}

function fillView(view) {
  el('view-title').value = view.title;
  el('view-subtitle').value = view.subtitle;
  el('view-tolerance').value = String(view.tolerance);
  el('view-stroke').value = String(view.stroke);
  el('view-interval').value = String(view.intervalSec);
  el('view-tint').checked = view.colorValues === true;
}

function fillEditor(source) {
  fillMenuList(source.menus || []);
  el('input-editor').replaceChildren();
  for (const input of source.inputs) appendCard(input);
  fillView(source.view);
  refreshRoleOptions();
  el('ist-select').value = source.view.istId || '';
  el('soll-select').value = source.view.sollId || '';
}

function readDraftFromForm() {
  const inputs = [...el('input-editor').querySelectorAll('.editor-card')].map((card) => {
    const label = card.querySelector('[data-field="label"]').value.trim();
    const rangeValue = card.querySelector('[data-field="range"]').value;
    const range = rangeValue === 'I' || rangeValue === 'Q' ? rangeValue : 'V';
    const address = Number(card.querySelector('[data-field="address"]').value.trim());
    const divisor = parseLooseNumber(card.querySelector('[data-field="divisor"]').value);
    const decimals = Number(card.querySelector('[data-field="decimals"]').value.trim());
    const demo = parseLooseNumber(card.querySelector('[data-field="demo"]').value);
    const faceValue = card.querySelector('[data-field="face"]').value;
    const face = faceValue === 'gauge' || faceValue === 'switch' || faceValue === 'lamp' ? faceValue : 'number';
    return {
      id: card.dataset.id,
      label: label.slice(0, 40),
      logo: card.querySelector('[data-field="logo"]').value,
      range,
      address,
      unit: card.querySelector('[data-field="unit"]').value.trim().slice(0, 8),
      divisor,
      decimals,
      color: normalizeColor(card.querySelector('[data-field="color"]').value),
      icon: symbolOf(card.querySelector('[data-field="icon"]').value),
      card: card.querySelector('[data-field="card"]').checked,
      chart: card.querySelector('[data-field="chart"]').checked,
      writable: (range !== 'V' || (face !== 'switch' && face !== 'lamp')) && card.querySelector('[data-field="writable"]').checked,
      demo,
      kind: face === 'switch' ? 'switch' : 'number',
      face,
      lamp: lampOf(card.querySelector('[data-field="lamp"]').value),
      onValue: card.querySelector('[data-field="onValue"]').value === '0' ? 0 : 1,
      scaleMin: parseLooseNumber(card.querySelector('[data-field="scaleMin"]').value),
      scaleMax: parseLooseNumber(card.querySelector('[data-field="scaleMax"]').value),
      zoneGreen: parseLooseNumber(card.querySelector('[data-field="zoneGreen"]').value),
      zoneBlue: parseLooseNumber(card.querySelector('[data-field="zoneBlue"]').value),
      zoneRed: parseLooseNumber(card.querySelector('[data-field="zoneRed"]').value),
      menu: selectedMenuIds(card.querySelector('[data-field="menus"]'))[0] || '',
      menus: selectedMenuIds(card.querySelector('[data-field="menus"]')),
      home: homePressed(card.querySelector('[data-field="menus"]')),
      signalLeft: card.querySelector('[data-field="signalLeft"]').value,
      signalRight: card.querySelector('[data-field="signalRight"]').value
    };
  });
  const view = {
    title: el('view-title').value.trim().slice(0, 60),
    subtitle: el('view-subtitle').value.trim().slice(0, 120),
    istId: el('ist-select').value,
    sollId: el('soll-select').value,
    tolerance: parseLooseNumber(el('view-tolerance').value),
    stroke: parseLooseNumber(el('view-stroke').value),
    intervalSec: Number(el('view-interval').value.trim()),
    colorValues: el('view-tint').checked
  };
  const menus = draftMenus();
  const menuIds = new Set(menus.map((menu) => menu.id));
  const ids = new Set(inputs.map((input) => input.id));
  for (const input of inputs) {
    input.menus = (input.menus || []).filter((id) => menuIds.has(id));
    input.menu = input.menus[0] || '';
    if (!ids.has(input.signalLeft) || input.signalLeft === input.id) input.signalLeft = '';
    if (!ids.has(input.signalRight) || input.signalRight === input.id || input.signalRight === input.signalLeft) input.signalRight = '';
  }
  return {inputs, view, menus};
}

function validateDraft(draft) {
  if ((draft.menus || []).length > 8) return t('Höchstens acht Menüs.');
  const menuIds = new Set();
  for (const menu of draft.menus || []) {
    if (!menu.name) return t('Jedes Menü braucht einen Namen.');
    if (!/^[a-z][a-z0-9]{0,15}$/.test(menu.id) || menuIds.has(menu.id)) return t('Doppeltes Menü.');
    menuIds.add(menu.id);
  }
  if (draft.inputs.length < 1) return t('Mindestens ein Eingang ist nötig.');
  if (draft.inputs.length > INPUT_CAP) return t('Höchstens 24 Eingänge. Einen entfernen, dann kann ein neuer dazu.');
  const ids = new Set();
  const addresses = new Set();
  for (const input of draft.inputs) {
    const name = input.label || t('Eingang');
    if ((input.menus || []).some((id) => !menuIds.has(id))) return t('Das Menü von „{name}“ fehlt.', {name});
    if (!input.label) return t('Jeder Eingang braucht einen Namen.');
    if (!/^[a-zA-Z][a-zA-Z0-9_-]{0,31}$/.test(input.id) || ids.has(input.id)) return t('Doppelte interne Kennung.');
    ids.add(input.id);
    const range = input.range === 'I' || input.range === 'Q' ? input.range : 'V';
    if (range === 'V' && (!Number.isInteger(input.address) || input.address < 0 || input.address > 65535)) {
      return t('Adresse von „{name}“ muss eine ganze Zahl von 0 bis 65535 sein.', {name});
    }
    if (range !== 'V' && (!Number.isInteger(input.address) || input.address < 1 || input.address > 128)) {
      return t('Adresse von „{name}“ muss für {range} eine ganze Zahl von 1 bis 128 sein.', {name, range});
    }
    const logo = input.logo || (logos[0] && logos[0].id) || '';
    if (logo && !/^[a-z][a-z0-9]{0,15}$/.test(logo)) return t('Ungültiges LOGO-Gerät bei „{name}“.', {name});
    if (logos.length && logo && !logos.some((item) => item.id === logo)) return t('Das LOGO-Gerät von „{name}“ fehlt.', {name});
    const point = logo + ':' + range + input.address;
    if (addresses.has(point)) return t('{point} ist auf diesem Gerät mehrfach vergeben.', {point: pointLabel({logo, range, address: input.address})});
    addresses.add(point);
    if (!(input.divisor > 0) || input.divisor > 100000) return t('Teiler von „{name}“ ist ungültig.', {name});
    if (!Number.isInteger(input.decimals) || input.decimals < 0 || input.decimals > 3) {
      return t('Nachkommastellen von „{name}“ müssen 0 bis 3 sein.', {name});
    }
    if (!input.color) return t('Farbe von „{name}“ ist ungültig.', {name});
    if (!Number.isFinite(input.demo) || Math.abs(input.demo) > 50000) return t('Demo-Wert von „{name}“ ist ungültig.', {name});
    if (!Number.isFinite(input.scaleMin) || !Number.isFinite(input.scaleMax) || input.scaleMax <= input.scaleMin) {
      return t('Tacho-Bereich von „{name}“: „bis“ muss grösser als „von“ sein.', {name});
    }
    if (Math.abs(input.scaleMin) > 5000 || Math.abs(input.scaleMax) > 5000) {
      return t('Tacho-Bereich von „{name}“ muss zwischen -5000 und 5000 liegen.', {name});
    }
    const zones = [input.zoneGreen, input.zoneBlue, input.zoneRed];
    if (!zones.every((value) => Number.isFinite(value) && value >= input.scaleMin && value <= input.scaleMax) || new Set(zones).size !== zones.length) {
      return t('Farbbereiche von „{name}“: Grün ab, Blau ab und Rot ab müssen verschieden zwischen Tacho von und Tacho bis liegen. Der kleinste Wert beginnt unten links.', {name});
    }
  }
  if ((draft.view.istId && !draft.view.sollId) || (!draft.view.istId && draft.view.sollId)) {
    return t('Für den Vergleich bitte Ist und Soll wählen, oder beides auf „Kein Vergleich“ stellen.');
  }
  if (draft.view.istId && draft.view.istId === draft.view.sollId) return t('Ist- und Soll-Eingang müssen verschieden sein.');
  if (draft.view.istId && !ids.has(draft.view.istId)) return t('Der Ist-Eingang ist nicht mehr vorhanden.');
  if (draft.view.sollId && !ids.has(draft.view.sollId)) return t('Der Soll-Eingang ist nicht mehr vorhanden.');
  if (!draft.view.title) return t('Der Titel darf nicht leer sein.');
  if (!(draft.view.tolerance >= 0) || draft.view.tolerance > 100) return t('Toleranz muss zwischen 0 und 100 liegen.');
  if (!(draft.view.stroke >= 1) || draft.view.stroke > 8) return t('Linienbreite muss zwischen 1 und 8 liegen.');
  if (!Number.isInteger(draft.view.intervalSec) || draft.view.intervalSec < 5 || draft.view.intervalSec > 300) {
    return t('Intervall muss eine ganze Zahl zwischen 5 und 300 Sekunden sein.');
  }
  return '';
}

function moveCard(card, direction) {
  const sibling = direction < 0 ? card.previousElementSibling : card.nextElementSibling;
  if (!sibling) return;
  const parent = card.parentElement;
  if (direction < 0) parent.insertBefore(card, sibling);
  else parent.insertBefore(card, sibling.nextSibling);
}

function addNamedMenu(name) {
  const clean = String(name || '').trim().slice(0, 40);
  if (!clean) return;
  const taken = draftMenus().some((menu) => menu.name.toLocaleLowerCase() === clean.toLocaleLowerCase());
  if (taken) return;
  addMenuRow({id: newMenuId(), name: clean});
}

function bindMenuPicker() {
  const filter = el('menu-filter');
  const list = el('menu-presets');
  if (!filter || !list || filter.dataset.bound) return;
  filter.dataset.bound = '1';
  function renderMenuPresets() {
    const query = filter.value.trim().toLocaleLowerCase(typeof hmLang === 'function' ? hmLang() : 'de');
    const matches = MENU_PRESETS.filter((preset) => presetMatches(preset, query));
    list.replaceChildren();
    list.hidden = matches.length === 0;
    for (const preset of matches) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'preset';
      button.textContent = t(preset.name) + ' · ' + t(preset.group);
      button.addEventListener('mousedown', (event) => {
        event.preventDefault();
        addNamedMenu(t(preset.name));
        filter.value = '';
        list.hidden = true;
      });
      list.append(button);
    }
  }
  filter.addEventListener('focus', renderMenuPresets);
  filter.addEventListener('input', renderMenuPresets);
  filter.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    addNamedMenu(filter.value);
    filter.value = '';
    list.hidden = true;
  });
  filter.addEventListener('blur', () => setTimeout(() => { list.hidden = true; }, 150));
  el('add-menu').addEventListener('click', () => {
    addNamedMenu(filter.value);
    filter.value = '';
    list.hidden = true;
  });
}

function bindEditor() {
  bindMenuPicker();
  el('toggle-settings').addEventListener('click', async () => {
    const body = el('settings-body');
    const willOpen = body.hidden;
    if (willOpen) await loadLogos();
    if (willOpen && !editorReady) {
      fillEditor(config);
      editorReady = true;
      setSettingsMessage('', true);
    }
    body.hidden = !willOpen;
    el('toggle-settings').textContent = willOpen ? t('Schliessen') : t('Anpassen');
    el('toggle-settings').setAttribute('aria-expanded', willOpen ? 'true' : 'false');
  });

  el('input-editor').addEventListener('click', (event) => {
    const button = event.target.closest('button');
    if (!button) return;
    const card = button.closest('.editor-card');
    if (!card) return;
    if (button.dataset.action === 'remove') {
      if (el('input-editor').children.length <= 1) return;
      const id = card.dataset.id;
      card.remove();
      refreshRoleOptions();
      if (el('ist-select').value === id) el('ist-select').value = '';
      if (el('soll-select').value === id) el('soll-select').value = '';
    } else if (button.dataset.action === 'up') {
      moveCard(card, -1);
    } else if (button.dataset.action === 'down') {
      moveCard(card, 1);
    }
  });

  el('add-input').addEventListener('click', () => {
    const count = el('input-editor').children.length;
    if (count >= INPUT_CAP) return;
    const used = new Set();
    for (const field of el('input-editor').querySelectorAll('[data-field="address"]')) {
      const value = Number(field.value.trim());
      if (Number.isInteger(value)) used.add(value);
    }
    let address = 208;
    while (used.has(address)) address += 1;
    appendCard({
      id: 'e' + Math.random().toString(36).slice(2, 8),
      label: t('Neuer Eingang'),
      range: 'V',
      address,
      unit: '',
      divisor: 1,
      decimals: 0,
      color: PALETTE[count % PALETTE.length],
      icon: '●',
      card: true,
      chart: true,
      writable: false,
      demo: 0,
      kind: 'number',
      face: 'number',
      lamp: 'green',
      onValue: 1,
      menu: '',
      menus: [],
      home: true,
      signalLeft: '',
      signalRight: '',
      scaleMin: 0,
      scaleMax: 80,
      zoneGreen: 0,
      zoneBlue: 32,
      zoneRed: 64
    });
    refreshRoleOptions();
  });

  el('apply-config').addEventListener('click', async () => {
    const draft = readDraftFromForm();
    const message = validateDraft(draft);
    if (message) {
      setSettingsMessage(message, false);
      return;
    }
    const next = {inputs: draft.inputs, view: draft.view, menus: draft.menus};
    const sameStructure = structureKey(config.inputs) === structureKey(next.inputs);
    const autoOn = interval !== null;
    applyState(next, false);
    try {
      await saveConfig(config);
    } catch (error) {
      setSettingsMessage(t('Speichern fehlgeschlagen: {error}', {error: t(error.message)}), false);
      render();
      return;
    }
    render();
    setSettingsMessage(t('Übernommen. Die QNAP verwendet diese Eingänge auf allen Geräten.'), true);
    if (!autoOn) return;
    if (!sameStructure) {
      const ok = await read();
      if (ok) startAuto();
      else stopAuto();
      return;
    }
    startAuto();
  });

  el('reset-config').addEventListener('click', async () => {
    if (!window.confirm(t('Standard-Eingänge und Darstellung wiederherstellen?'))) return;
    const autoOn = interval !== null;
    applyState(defaultConfig(), true);
    bootState();
    if (archive.length) setStatus('saved', t('Letzte gespeicherte Messung'));
    else {
      mode = 'demo';
      setStatus('demo', t('Demo-Modus · keine Live-Daten'));
      el('last').textContent = t('Beispieldaten');
    }
    try {
      await saveConfig(config);
    } catch (error) {
      setSettingsMessage(t('Speichern fehlgeschlagen: {error}', {error: t(error.message)}), false);
    }
    fillEditor(config);
    editorReady = true;
    render();
    setSettingsMessage(t('Standard wiederhergestellt.'), true);
    if (autoOn) stopAuto();
  });
}

function bindLive() {
  el('load').addEventListener('click', read);
  el('auto').addEventListener('click', async () => {
    if (interval) {
      stopAuto();
      return;
    }
    const ok = await read();
    if (ok) startAuto();
  });
}

function newerArchive(left, right) {
  const last = (list) => list.length ? list[list.length - 1].t : 0;
  return last(left) >= last(right) ? left : right;
}

function normalizeArchive(raw) {
  const list = Array.isArray(raw) ? raw : [];
  const cutoff = Date.now() - ARCHIVE_KEEP_MS;
  const incoming = [];
  for (const item of list) {
    const time = Number(item?.t);
    if (!Number.isFinite(time) || time < cutoff || time > Date.now() + 60000) continue;
    const source = item.v && typeof item.v === 'object' ? item.v : null;
    if (!source) continue;
    const values = {};
    for (const [key, value] of Object.entries(source)) {
      if (!/^[a-zA-Z][a-zA-Z0-9_-]{0,31}$/.test(key)) continue;
      const number = Number(value);
      if (Number.isFinite(number) && Math.abs(number) <= 50000) values[key] = number;
    }
    if (!Object.keys(values).length) continue;
    const sample = {t: time, v: values};
    const rawSource = item.r && typeof item.r === 'object' ? item.r : null;
    if (rawSource) {
      const raw = {};
      for (const [key, value] of Object.entries(rawSource)) {
        if (!/^[a-zA-Z][a-zA-Z0-9_-]{0,31}$/.test(key)) continue;
        const number = Number(value);
        if (Number.isFinite(number) && Math.abs(number) <= 50000) raw[key] = number;
      }
      if (Object.keys(raw).length) sample.r = raw;
    }
    incoming.push(sample);
  }
  incoming.sort((a, b) => a.t - b.t);
  const collapsed = [];
  for (const sample of incoming) {
    const previous = collapsed[collapsed.length - 1];
    if (previous && sample.t - previous.t < ARCHIVE_GAP_MS) collapsed[collapsed.length - 1] = sample;
    else collapsed.push(sample);
  }
  return collapsed.slice(-20000);
}

function readLocalArchive() {
  try {
    return normalizeArchive(JSON.parse(localStorage.getItem(ARCHIVE_KEY) || '[]'));
  } catch {
    return [];
  }
}

async function fetchArchive(since) {
  const response = await fetch('/api/archive?since=' + since, {cache: 'no-store'});
  if (response.status === 404) return null;
  if (!response.ok) return [];
  const data = await response.json();
  return normalizeArchive(data.samples);
}

async function loadArchive() {
  try {
    const remote = await fetchArchive(0);
    if (remote === null) {
      const local = readLocalArchive();
      if (local.length) {
        const saved = await fetch('/api/archive', {
          method: 'PUT',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({samples: local})
        });
        if (saved.ok) {
          const seeded = normalizeArchive((await saved.json()).samples);
          archiveCursor = seeded.length ? seeded[seeded.length - 1].t : 0;
          return seeded;
        }
      }
      return [];
    }
    archiveCursor = remote.length ? remote[remote.length - 1].t : 0;
    return remote;
  } catch {
    return readLocalArchive();
  }
}

async function pullArchive() {
  const incoming = await fetchArchive(archiveCursor);
  if (!incoming || !incoming.length) return;
  archive = archiveCursor ? normalizeArchive(archive.concat(incoming)) : incoming;
  archiveCursor = archive.length ? archive[archive.length - 1].t : archiveCursor;
  render();
}

function saveArchive() {
  try {
    localStorage.setItem(ARCHIVE_KEY, JSON.stringify(archive));
  } catch {
    el('history-note').textContent = t('Historie konnte nicht gespeichert werden. Der Browser-Speicher ist voll.');
  }
  if (typeof chrome !== 'undefined' && chrome.storage?.local) {
    chrome.storage.local.set({[ARCHIVE_KEY]: archive}).catch(() => {});
  }
}

function flushArchive() {
  if (archiveTimer) clearTimeout(archiveTimer);
  archiveTimer = null;
  if (!archiveReady || !archiveDirty) return;
  archiveDirty = false;
  saveArchive();
}

function remember(values) {
  const now = Date.now();
  const sample = {t: now, v: {}, r: {}};
  for (const input of config.inputs) {
    if (inputErrors[input.id]) continue;
    const number = Number(values[input.id]);
    if (Number.isFinite(number)) sample.v[input.id] = Math.round(number * 1000) / 1000;
    const raw = Number(rawState[input.id]);
    if (Number.isFinite(raw)) sample.r[input.id] = raw;
  }
  if (!Object.keys(sample.r).length) delete sample.r;
  if (!Object.keys(sample.v).length) return;
  const previous = archive[archive.length - 1];
  if (previous && now - previous.t < ARCHIVE_GAP_MS) {
    sample.t = previous.t;
    sample.v = Object.assign({}, previous.v, sample.v);
    const raw = Object.assign({}, previous.r || {}, sample.r || {});
    if (Object.keys(raw).length) sample.r = raw;
    else delete sample.r;
    archive[archive.length - 1] = sample;
  } else archive.push(sample);
  const cutoff = now - ARCHIVE_KEEP_MS;
  if (archive.length && archive[0].t < cutoff) archive = archive.filter((sampleItem) => sampleItem.t >= cutoff);
  if (archive.length > 20000) archive = archive.slice(-20000);
  archiveDirty = true;
  if (archiveTimer) clearTimeout(archiveTimer);
  archiveTimer = setTimeout(flushArchive, 1500);
}

function csvCell(value) {
  const text = String(value ?? '');
  return /[;"\r\n]/.test(text) ? '"' + text.replace(/"/g, '""') + '"' : text;
}

function csvNumber(value, digits) {
  return Number(value).toFixed(digits).replace('.', ',');
}

function exportArchive() {
  if (!archive.length) return;
  const inputs = scopedInputs().filter((input) => archive.some((sample) => Number.isFinite(archivedValue(sample, input))));
  const header = ['Zeit'];
  for (const input of inputs) {
    const unit = input.unit ? ' ' + input.unit : '';
    header.push(input.label + unit, input.label + ' Rohwert');
  }
  const lines = [header.map(csvCell).join(';')];
  const pad = (number) => String(number).padStart(2, '0');
  for (const sample of archive) {
    const stamp = new Date(sample.t);
    const zeit = stamp.getFullYear() + '-' + pad(stamp.getMonth() + 1) + '-' + pad(stamp.getDate()) + ' ' + pad(stamp.getHours()) + ':' + pad(stamp.getMinutes()) + ':' + pad(stamp.getSeconds());
    const cells = [zeit];
    for (const input of inputs) {
      const value = archivedValue(sample, input);
      const raw = sample.r ? Number(sample.r[input.id]) : NaN;
      const digital = input.kind === 'switch' || faceOf(input) === 'lamp';
      cells.push(Number.isFinite(value) ? (digital ? (signalOn(value, input) ? 'Ein' : 'Aus') : csvNumber(value, input.decimals)) : '');
      cells.push(Number.isFinite(raw) ? csvNumber(raw, Number.isInteger(raw) ? 0 : 1) : '');
    }
    lines.push(cells.map(csvCell).join(';'));
  }
  const blob = new Blob(['\uFEFF' + lines.join('\r\n')], {type: 'text/csv;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  const now = new Date();
  link.href = url;
  link.download = 'heizungsmonitor-' + now.getFullYear() + '-' + pad(now.getMonth() + 1) + '-' + pad(now.getDate()) + '.csv';
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

function loadHiddenSeries() {
  try {
    const raw = JSON.parse(localStorage.getItem(HIDDEN_KEY) || '[]');
    hiddenSeries = new Set(Array.isArray(raw) ? raw.filter((id) => typeof id === 'string') : []);
  } catch {
    hiddenSeries = new Set();
  }
}

function saveHiddenSeries() {
  localStorage.setItem(HIDDEN_KEY, JSON.stringify([...hiddenSeries]));
}

function loadChartSize() {
  chartLarge = localStorage.getItem(CHART_SIZE_KEY) === '1';
  chartHidden = localStorage.getItem(CHART_HIDE_KEY) === '1';
  chartFrom = Number(localStorage.getItem(CHART_FROM_KEY)) || 0;
  chartTo = Number(localStorage.getItem(CHART_TO_KEY)) || 0;
  if (chartFrom && chartTo && chartTo < chartFrom) {
    chartFrom = 0;
    chartTo = 0;
  }
}

function applyChartSize() {
  const split = document.querySelector('.split');
  if (split) split.classList.toggle('wide', chartLarge);
  const button = el('chart-size');
  if (!button) return;
  button.textContent = chartLarge ? t('Verkleinern') : t('Vergrössern');
  button.setAttribute('aria-pressed', chartLarge ? 'true' : 'false');
}

function localInputValue(time) {
  if (!time) return '';
  const date = new Date(time);
  if (Number.isNaN(date.getTime())) return '';
  const pad = (value) => String(value).padStart(2, '0');
  return date.getFullYear() + '-' + pad(date.getMonth() + 1) + '-' + pad(date.getDate()) + 'T' + pad(date.getHours()) + ':' + pad(date.getMinutes());
}

function stampFromInput(value) {
  if (!value) return 0;
  const time = new Date(value).getTime();
  return Number.isFinite(time) ? time : 0;
}

function fillTimeFilter() {
  const from = el('chart-from');
  const to = el('chart-to');
  if (from) from.value = localInputValue(chartFrom);
  if (to) to.value = localInputValue(chartTo);
}

function applyChartHidden() {
  const body = el('chart-body');
  const button = el('chart-hide');
  if (body) body.hidden = chartHidden;
  if (!button) return;
  button.textContent = chartHidden ? t('Einblenden') : t('Ausblenden');
  button.setAttribute('aria-pressed', chartHidden ? 'true' : 'false');
  button.setAttribute('aria-expanded', chartHidden ? 'false' : 'true');
}

function storeTimeFilter(from, to) {
  chartFrom = from;
  chartTo = to;
  localStorage.setItem(CHART_FROM_KEY, from ? String(from) : '');
  localStorage.setItem(CHART_TO_KEY, to ? String(to) : '');
}

function clearTimeFilter() {
  storeTimeFilter(0, 0);
  fillTimeFilter();
}

function loadRange() {
  const stored = localStorage.getItem(RANGE_KEY);
  return RANGES.some((item) => item.id === stored) ? stored : '24h';
}

function renderRangeButtons() {
  const bar = el('rangebar');
  if (!bar) return;
  if (bar.childElementCount !== RANGES.length) {
    bar.replaceChildren();
    for (const range of RANGES) {
      const button = document.createElement('button');
      button.type = 'button';
      button.dataset.range = range.id;
      button.textContent = t(range.label);
      bar.append(button);
    }
  }
  const custom = customWindow();
  for (const button of bar.children) {
    button.setAttribute('aria-pressed', !custom && button.dataset.range === rangeId ? 'true' : 'false');
  }
}

function renderReadout(sample) {
  const box = el('history-readout');
  box.replaceChildren();
  const time = document.createElement('strong');
  time.textContent = formatStamp(sample.t);
  box.append(time);
  for (const input of chartInputs()) {
    const value = archivedValue(sample, input);
    if (!Number.isFinite(value)) continue;
    const span = document.createElement('span');
    const swatch = document.createElement('i');
    swatch.className = 'key';
    swatch.style.background = input.color;
    const digital = input.kind === 'switch' || faceOf(input) === 'lamp';
    const unit = digital || !input.unit ? '' : ' ' + input.unit;
    const text = digital ? (signalOn(value, input) ? 'Ein' : 'Aus') : displayValue(input, value);
    span.append(swatch, document.createTextNode(input.label + ' ' + text + unit));
    box.append(span);
  }
}

function onChartPointer(event) {
  if (!chartModel || !chartModel.points.length) return;
  const rect = el('graph').getBoundingClientRect();
  if (!rect.width) return;
  const viewX = (event.clientX - rect.left) / rect.width * chartModel.w;
  let best = chartModel.points[0];
  let bestDistance = Infinity;
  for (const point of chartModel.points) {
    const distance = Math.abs(chartModel.xx(point.t) - viewX);
    if (distance < bestDistance) {
      best = point;
      bestDistance = distance;
    }
  }
  const x = chartModel.xx(best.t);
  const cursor = el('graph').querySelector('#cursor');
  if (cursor) {
    cursor.setAttribute('x1', String(x));
    cursor.setAttribute('x2', String(x));
    cursor.setAttribute('y1', String(chartModel.T));
    cursor.setAttribute('y2', String(chartModel.h - chartModel.B));
    cursor.setAttribute('visibility', 'visible');
  }
  renderReadout(best);
}

function bindHistory() {
  el('rangebar').addEventListener('click', (event) => {
    const button = event.target.closest('button');
    if (!button?.dataset.range) return;
    rangeId = button.dataset.range;
    localStorage.setItem(RANGE_KEY, rangeId);
    clearTimeFilter();
    el('history-readout').replaceChildren();
    render();
  });
  const filterButton = el('chart-filter');
  const clearFilterButton = el('chart-filter-clear');
  const hideButton = el('chart-hide');
  if (filterButton) {
    filterButton.addEventListener('click', () => {
      const from = stampFromInput(el('chart-from').value);
      const to = stampFromInput(el('chart-to').value);
      if (from && to && to < from) {
        el('history-note').textContent = t('„Bis“ muss nach „Von“ liegen.');
        return;
      }
      storeTimeFilter(from, to);
      el('history-readout').replaceChildren();
      render();
    });
  }
  if (clearFilterButton) {
    clearFilterButton.addEventListener('click', () => {
      clearTimeFilter();
      el('history-readout').replaceChildren();
      render();
    });
  }
  if (hideButton) {
    hideButton.addEventListener('click', () => {
      chartHidden = !chartHidden;
      localStorage.setItem(CHART_HIDE_KEY, chartHidden ? '1' : '0');
      applyChartHidden();
    });
  }
  el('legend').addEventListener('click', (event) => {
    const button = event.target.closest('button');
    if (!button?.dataset.series) return;
    const id = button.dataset.series;
    if (hiddenSeries.has(id)) hiddenSeries.delete(id);
    else hiddenSeries.add(id);
    saveHiddenSeries();
    el('history-readout').replaceChildren();
    render();
  });
  const svg = el('graph');
  svg.addEventListener('pointermove', onChartPointer);
  svg.addEventListener('pointerdown', onChartPointer);
  svg.addEventListener('pointerleave', () => {
    const cursor = svg.querySelector('#cursor');
    if (cursor) cursor.setAttribute('visibility', 'hidden');
  });
  el('chart-size').addEventListener('click', () => {
    chartLarge = !chartLarge;
    localStorage.setItem(CHART_SIZE_KEY, chartLarge ? '1' : '0');
    applyChartSize();
  });
  el('export-history').addEventListener('click', exportArchive);
  el('clear-history').addEventListener('click', async () => {
    if (!archive.length) return;
    if (!window.confirm(t('Gespeicherte Temperaturhistorie löschen?'))) return;
    await fetch('/api/archive', {method: 'DELETE'});
    archive = [];
    archiveCursor = 0;
    archiveDirty = false;
    localStorage.removeItem(ARCHIVE_KEY);
    chartModel = null;
    el('history-readout').replaceChildren();
    render();
  });
  window.addEventListener('pagehide', flushArchive);
}

function bootState() {
  const last = archive[archive.length - 1];
  rawState = {};
  state = Object.fromEntries(config.inputs.map((input) => {
    const raw = last && last.r ? Number(last.r[input.id]) : NaN;
    if (Number.isFinite(raw) && input.divisor > 0) {
      rawState[input.id] = raw;
      return [input.id, raw / input.divisor];
    }
    const saved = last ? Number(last.v[input.id]) : NaN;
    return [input.id, Number.isFinite(saved) ? saved : input.demo];
  }));
  mode = archive.length ? 'saved' : 'demo';
  if (last) el('last').textContent = formatStamp(last.t);
}

function formatWeatherNumber(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return '';
  const rounded = Math.round(number * 10) / 10;
  return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1).replace('.', ',');
}

function formatWeatherTemp(value) {
  const text = formatWeatherNumber(value);
  return text ? text + '°' : '';
}

function renderWeek(days) {
  const week = el('week');
  if (!week) return;
  const list = Array.isArray(days) ? days.slice(0, 7) : [];
  if (!list.length) {
    week.hidden = true;
    week.replaceChildren();
    return;
  }
  week.hidden = false;
  week.replaceChildren(...list.map((day) => {
    const card = document.createElement('article');
    card.className = 'day' + (day.today ? ' today' : '');
    const name = document.createElement('div');
    name.className = 'name';
    name.textContent = t(day.day || '');
    const high = document.createElement('strong');
    high.textContent = formatWeatherTemp(day.max) || '–';
    const low = document.createElement('div');
    low.className = 'low';
    low.textContent = formatWeatherTemp(day.min);
    const kind = document.createElement('div');
    kind.className = 'kind';
    kind.textContent = t(day.text || '');
    card.append(name, high, low, kind);
    if (Number(day.rain) >= 30) {
      const rain = document.createElement('div');
      rain.className = 'low';
      rain.textContent = t('Regen {value} %', {value: formatWeatherNumber(day.rain)});
      card.append(rain);
    }
    return card;
  }));
}

async function showWeather() {
  const box = el('weather');
  if (!box) return;
  try {
    const response = await fetch('/api/weather', {cache: 'no-store'});
    if (response.status === 401) return;
    const data = await response.json().catch(() => ({}));
    box.hidden = false;
    if (!data.enabled) {
      box.className = 'weather weather-empty';
      box.replaceChildren(document.createTextNode(t('Wetter einrichten')));
      box.setAttribute('aria-label', t('Wetter einrichten'));
      renderWeek([]);
      return;
    }
    box.className = 'weather';
    const nodes = [];
    const temp = formatWeatherTemp(data.temperature);
    if (temp) {
      const strong = document.createElement('strong');
      strong.textContent = temp;
      nodes.push(strong);
    }
    const text = document.createElement('span');
    text.textContent = t(data.text || 'Wetter');
    nodes.push(text);
    const bits = [];
    if (data.label) bits.push(data.label);
    const low = formatWeatherTemp(data.min);
    const high = formatWeatherTemp(data.max);
    if (low && high) bits.push(low + ' ' + t('bis') + ' ' + high);
    const wind = formatWeatherNumber(data.wind);
    if (Number(data.wind) > 0) bits.push(t('Wind {value} km/h', {value: wind}));
    const rain = formatWeatherNumber(data.rain);
    if (Number(data.rain) > 0) bits.push(t('Regen {value} %', {value: rain}));
    const apparent = formatWeatherTemp(data.apparent);
    if (apparent && apparent !== temp) bits.push(t('gefühlt {value}', {value: apparent}));
    if (data.error) bits.push(data.error);
    if (bits.length) {
      const meta = document.createElement('span');
      meta.className = 'weather-meta';
      meta.textContent = bits.join(' · ');
      nodes.push(meta);
    }
    box.replaceChildren(...nodes);
    box.setAttribute('aria-label', ['Wetter', temp, data.text, data.label].filter(Boolean).join(', '));
    renderWeek(data.days);
  } catch { /* die Leiste bleibt leer */ }
}

function fillLogoSelect(select, current) {
  const value = logoIdOf({logo: current}) || (logos[0] && logos[0].id) || '';
  const list = logos.length ? logos : [{id: '', name: 'LOGO'}];
  select.replaceChildren();
  for (const item of list) select.append(new Option(item.name || item.host, item.id));
  if (value && ![...select.options].some((option) => option.value === value)) select.append(new Option(value, value));
  select.value = [...select.options].some((option) => option.value === value) ? value : (select.options[0] ? select.options[0].value : '');
}

function refreshLogoSelects() {
  const editor = el('input-editor');
  if (!editor) return;
  for (const select of editor.querySelectorAll('[data-field="logo"]')) fillLogoSelect(select, select.value);
}

async function loadLogos() {
  try {
    const response = await fetch('/api/logos', {cache: 'no-store'});
    if (response.status === 401) return;
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !Array.isArray(data.logos)) return;
    logos = data.logos.filter((item) => item && typeof item.id === 'string' && typeof item.name === 'string');
    const strong = document.querySelector('#host strong');
    if (strong && logos.length) {
      strong.textContent = logos.map((item) => item.name + (item.host ? ' ' + item.host : '')).join(' · ');
    }
    if (editorReady) refreshLogoSelects();
    if (config && config.inputs) render();
  } catch { /* die feste Anzeige bleibt */ }
}

async function init() {
  config = await loadConfig();
  archive = await loadArchive();
  archiveReady = true;
  rangeId = loadRange();
  loadChartSize();
  applyChartSize();
  fillTimeFilter();
  applyChartHidden();
  loadHiddenSeries();
  bootState();
  try { bindEditor(); } catch (error) { console.error(error); }
  try { bindLive(); } catch (error) { console.error(error); }
  window.addEventListener('hashchange', () => render());
  window.addEventListener('popstate', () => render());
  const home = document.querySelector('.nav a[href="/"]');
  if (home) {
    home.addEventListener('click', (event) => {
      event.preventDefault();
      history.pushState(null, '', location.pathname + location.search);
      render();
    });
  }
  try { bindHistory(); } catch (error) { console.error(error); }
  document.documentElement.addEventListener('hm-theme', () => {
    if (document.getElementById('metrics')) render();
  });
  render();
  await loadLogos();
  showWeather();
  setInterval(() => showWeather(), 15 * 60 * 1000);
  if (archive.length) setStatus('saved', t('Letzte gespeicherte Messung'));
  const live = await read();
  if (live) startAuto();
  setInterval(() => {
    pullConfig().catch(() => {});
    pullArchive().catch(() => {});
  }, 15000);
}

init();
