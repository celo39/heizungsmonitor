#!/usr/bin/env python3
"""Heizungsmonitor für die QNAP. Liest und schreibt direkt bei der LOGO! 9."""

import base64
import datetime
import hashlib
import hmac
import ipaddress
import json
import os
import re
import secrets
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(os.environ.get('PORT', '8080'))
DATA_DIR = os.environ.get('DATA_DIR', '/data')
SETTINGS_PATH = os.path.join(DATA_DIR, 'settings.json')
CONFIG_PATH = os.path.join(DATA_DIR, 'monitor.json')
ARCHIVE_PATH = os.path.join(DATA_DIR, 'archive.json')
WEATHER_PATH = os.path.join(DATA_DIR, 'weather.json')
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
PBKDF2_ROUNDS = 120_000
MAX_BODY = 4096
CONFIG_BODY = 65_536
ARCHIVE_BODY = 6_000_000
SESSION_TTL = 12 * 60 * 60
ARCHIVE_KEEP_MS = 14 * 24 * 60 * 60 * 1000
ARCHIVE_GAP_MS = 60 * 1000
ARCHIVE_CAP = 20000
INPUT_ID = re.compile(r'^[A-Za-z][A-Za-z0-9_-]{0,31}$')
LOGO_ID = re.compile(r'^[a-z][a-z0-9]{0,15}$')
MENU_ID = re.compile(r'^[a-z][a-z0-9]{0,15}$')

sessions = {}
sessions_lock = threading.Lock()
login_fails = {}
settings_lock = threading.Lock()
config_lock = threading.Lock()
archive_lock = threading.Lock()
archive_state = []
archive_ready = False
archive_last_flush = 0.0
weather_lock = threading.Lock()
weather_cache = {'key': '', 'at': 0.0, 'ttl': 0.0, 'payload': None}
WEATHER_TTL = 15 * 60


def u32(value):
    return int(value) & 0xFFFFFFFF


def logo_crc32(text):
    return zlib.crc32(text.encode('utf-8')) & 0xFFFFFFFF


def check_logo_host(value):
    text = str(value or '').strip()
    parsed = urllib.parse.urlsplit(text)
    if parsed.scheme not in ('http', 'https') or parsed.username or parsed.password:
        raise ValueError('Die LOGO-Adresse muss mit http:// oder https:// beginnen.')
    if parsed.query or parsed.fragment or parsed.path not in ('', '/'):
        raise ValueError('Die LOGO-Adresse darf nur Host und optional einen Port enthalten.')
    if not parsed.hostname:
        raise ValueError('Die LOGO-Adresse fehlt.')
    try:
        address = ipaddress.ip_address(parsed.hostname)
    except ValueError:
        raise ValueError('Bitte die IP-Adresse der LOGO eintragen.')
    if not address.is_private or address.is_loopback or address.is_link_local or address.is_multicast:
        raise ValueError('Die LOGO muss im privaten Heimnetz liegen.')
    port = parsed.port or (443 if parsed.scheme == 'https' else 80)
    if port < 1 or port > 65535:
        raise ValueError('Ungültiger Port.')
    host = parsed.hostname
    if parsed.port:
        return '%s://%s:%s' % (parsed.scheme, host, parsed.port)
    return '%s://%s' % (parsed.scheme, host)


def hash_password(password, salt=None):
    if salt is None:
        salt = secrets.token_bytes(16)
    elif isinstance(salt, str):
        salt = bytes.fromhex(salt)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, PBKDF2_ROUNDS)
    return salt.hex(), digest.hex()


def password_matches(password, salt_hex, digest_hex):
    _, digest = hash_password(password, salt_hex)
    return hmac.compare_digest(digest, digest_hex)


def load_settings():
    try:
        with open(SETTINGS_PATH, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    needed = ('app_salt', 'app_hash', 'logo_host', 'logo_user', 'logo_password')
    if any(not isinstance(data.get(key), str) or not data.get(key) for key in needed):
        return None
    return data


def save_settings(data):
    os.makedirs(DATA_DIR, exist_ok=True)
    temporary = SETTINGS_PATH + '.tmp'
    with open(temporary, 'w', encoding='utf-8') as handle:
        json.dump(data, handle)
        handle.write('\n')
    os.chmod(temporary, 0o600)
    os.replace(temporary, SETTINGS_PATH)
    try:
        os.chmod(SETTINGS_PATH, 0o600)
    except OSError:
        pass


def clean_logo_name(value):
    text = ' '.join(str(value or '').split())
    if any(ord(char) < 32 for char in text) or not 1 <= len(text) <= 40:
        raise ValueError('Der Gerätename ist ungültig.')
    return text


def clean_logo_user(value):
    user = str(value or '').strip()
    if not user or len(user) > 40 or any(char in user for char in ',\r\n'):
        raise ValueError('Der LOGO-Benutzer ist ungültig.')
    return user


def logo_list(settings):
    raw = settings.get('logos') if isinstance(settings, dict) else None
    items = []
    seen = set()
    if isinstance(raw, list):
        for item in raw:
            if not isinstance(item, dict):
                continue
            ident = item.get('id')
            host = item.get('host')
            user = item.get('user')
            password = item.get('password')
            name = item.get('name')
            if not isinstance(ident, str) or not LOGO_ID.match(ident) or ident in seen:
                continue
            if not isinstance(host, str) or not host or not isinstance(user, str) or not isinstance(password, str) or not password:
                continue
            if not isinstance(name, str) or not name.strip():
                name = 'LOGO'
            items.append({
                'id': ident,
                'name': ' '.join(name.split())[:40],
                'host': host,
                'user': user,
                'password': password,
            })
            seen.add(ident)
            if len(items) == 8:
                break
    if items:
        return items
    if not isinstance(settings, dict) or not isinstance(settings.get('logo_host'), str) or not settings.get('logo_host'):
        return []
    return [{
        'id': 'haupt',
        'name': 'LOGO',
        'host': settings['logo_host'],
        'user': settings.get('logo_user') if isinstance(settings.get('logo_user'), str) else '',
        'password': settings.get('logo_password') if isinstance(settings.get('logo_password'), str) else '',
    }]


def public_logo(item):
    return {'id': item['id'], 'name': item['name'], 'host': item['host'], 'user': item['user']}


def find_logo(logo_id):
    settings = load_settings()
    if not settings:
        raise RuntimeError('Die LOGO-Anmeldung ist noch nicht eingerichtet.')
    logos = logo_list(settings)
    if not logos:
        raise RuntimeError('Die LOGO-Anmeldung ist noch nicht eingerichtet.')
    if not logo_id:
        return logos[0]
    for item in logos:
        if item['id'] == logo_id:
            return item
    raise RuntimeError('Dieses LOGO-Gerät ist nicht eingerichtet.')


def new_logo_id(existing_ids):
    for _ in range(20):
        ident = 'l' + secrets.token_hex(4)
        if ident not in existing_ids:
            return ident
    raise RuntimeError('Es ist kein weiteres LOGO-Gerät frei.')


def store_logos(existing, logos):
    first = logos[0]
    save_settings({
        'app_salt': existing['app_salt'],
        'app_hash': existing['app_hash'],
        'logo_host': first['host'],
        'logo_user': first['user'],
        'logo_password': first['password'],
        'logos': logos,
    })


def logo_in_use(logo_id, primary_id):
    config = load_monitor_config()
    if not config:
        return False
    for item in config.get('inputs') or []:
        current = item.get('logo') if isinstance(item.get('logo'), str) and item.get('logo') else primary_id
        if current == logo_id:
            return True
    return False


def parse_proxy_path(path):
    if path.startswith('/api/vi/'):
        rest = [part for part in path[len('/api/vi/'):].split('/') if part]
        if len(rest) == 1 and rest[0].isdigit():
            return '', 'V', int(rest[0])
        if len(rest) == 2 and LOGO_ID.match(rest[0]) and rest[1].isdigit():
            return rest[0], 'V', int(rest[1])
    if path.startswith('/api/io/'):
        rest = [part for part in path[len('/api/io/'):].split('/') if part]
        if len(rest) == 2 and rest[0] in ('I', 'Q') and rest[1].isdigit():
            return '', rest[0], int(rest[1])
        if len(rest) == 3 and LOGO_ID.match(rest[0]) and rest[1] in ('I', 'Q') and rest[2].isdigit():
            return rest[0], rest[1], int(rest[2])
    return None


def write_json(path, data, mode=0o600):
    os.makedirs(DATA_DIR, exist_ok=True)
    temporary = path + '.tmp'
    with open(temporary, 'w', encoding='utf-8') as handle:
        json.dump(data, handle, ensure_ascii=False, separators=(',', ':'))
        handle.write('\n')
    os.chmod(temporary, mode)
    os.replace(temporary, path)
    try:
        os.chmod(path, mode)
    except OSError:
        pass


def clean_menus(data):
    raw = data.get('menus')
    menus = []
    seen = set()
    if isinstance(raw, list):
        for item in raw:
            if len(menus) == 8:
                break
            if not isinstance(item, dict):
                continue
            menu_id = item.get('id')
            name = item.get('name')
            if not isinstance(menu_id, str) or not MENU_ID.match(menu_id) or menu_id in seen:
                continue
            if not isinstance(name, str):
                continue
            name = ' '.join(name.split())[:40]
            if not name:
                continue
            seen.add(menu_id)
            menus.append({'id': menu_id, 'name': name})
    data['menus'] = menus
    for item in data.get('inputs') or []:
        if not isinstance(item, dict):
            continue
        menu = item.get('menu') or ''
        places = item.get('menus')
        ids = []
        if isinstance(places, list):
            for menu_id in places:
                if isinstance(menu_id, str) and menu_id in seen and menu_id not in ids:
                    ids.append(menu_id)
        elif isinstance(menu, str) and menu in seen:
            ids.append(menu)
        item['menus'] = ids
        item['menu'] = ids[0] if ids else ''
        item['home'] = item.get('home') is not False
    return data


def valid_config(data):
    if not isinstance(data, dict):
        raise ValueError('Ungültige Einstellung.')
    clean_menus(data)
    inputs = data.get('inputs')
    view = data.get('view')
    if not isinstance(inputs, list) or not 1 <= len(inputs) <= 24 or not isinstance(view, dict):
        raise ValueError('Es braucht 1 bis 24 Eingänge.')
    seen_ids = set()
    seen_addresses = set()
    for item in inputs:
        if not isinstance(item, dict):
            raise ValueError('Ungültiger Eingang.')
        identifier = item.get('id')
        address = item.get('address')
        label = item.get('label')
        divisor = item.get('divisor')
        if not isinstance(identifier, str) or not INPUT_ID.match(identifier) or identifier in seen_ids:
            raise ValueError('Ungültiger Eingang.')
        area = item.get('range', 'V')
        if area not in ('V', 'I', 'Q'):
            raise ValueError('Ungültiger Bereich.')
        if isinstance(address, bool) or not isinstance(address, int):
            raise ValueError('Ungültige Adresse.')
        if area == 'V' and not 0 <= address <= 65535:
            raise ValueError('Ungültige Adresse.')
        if area in ('I', 'Q') and not 1 <= address <= 128:
            raise ValueError('I und Q gehen von 1 bis 128.')
        logo = item.get('logo') or ''
        if logo and (not isinstance(logo, str) or not LOGO_ID.match(logo)):
            raise ValueError('Ungültiges LOGO-Gerät.')
        known = logo_list(load_settings() or {})
        known_ids = {entry['id'] for entry in known}
        if logo and logo not in known_ids:
            raise ValueError('Das LOGO-Gerät ist nicht eingerichtet.')
        effective = logo or (known[0]['id'] if known else '')
        point = (effective, area, address)
        if point in seen_addresses:
            raise ValueError('Adresse %s%d ist auf diesem Gerät mehrfach vergeben.' % (area, address))
        if not isinstance(label, str) or not label.strip() or len(label) > 40:
            raise ValueError('Ungültiger Name.')
        if isinstance(divisor, bool) or not isinstance(divisor, (int, float)) or not 0 < float(divisor) <= 100000:
            raise ValueError('Ungültiger Teiler.')
        seen_ids.add(identifier)
        seen_addresses.add(point)
        for key in ('unit', 'icon', 'color', 'face', 'kind', 'lamp'):
            value = item.get(key)
            if value is not None and (not isinstance(value, str) or len(value) > 16):
                raise ValueError('Ungültiger Eingang.')
    return data


def load_monitor_config():
    try:
        with open(CONFIG_PATH, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        return valid_config(data)
    except (OSError, json.JSONDecodeError, ValueError):
        return None


def save_monitor_config(data):
    checked = valid_config(data)
    with config_lock:
        write_json(CONFIG_PATH, checked)
    return checked


def normalize_archive(raw):
    if not isinstance(raw, list):
        return []
    now = int(time.time() * 1000)
    cutoff = now - ARCHIVE_KEEP_MS
    incoming = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        stamp = item.get('t')
        values = item.get('v')
        if isinstance(stamp, bool) or not isinstance(stamp, (int, float)):
            continue
        stamp = int(stamp)
        if stamp < cutoff or stamp > now + 60000 or not isinstance(values, dict):
            continue
        kept = {}
        for key, value in values.items():
            if not isinstance(key, str) or not INPUT_ID.match(key):
                continue
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                continue
            number = float(value)
            if abs(number) <= 50000:
                kept[key] = number
        if not kept:
            continue
        sample = {'t': stamp, 'v': kept}
        raw_values = item.get('r')
        if isinstance(raw_values, dict):
            kept_raw = {}
            for key, value in raw_values.items():
                if not isinstance(key, str) or not INPUT_ID.match(key):
                    continue
                if isinstance(value, bool) or not isinstance(value, (int, float)):
                    continue
                number = float(value)
                if abs(number) <= 50000:
                    kept_raw[key] = int(number) if number.is_integer() else number
            if kept_raw:
                sample['r'] = kept_raw
        incoming.append(sample)
    incoming.sort(key=lambda sample: sample['t'])
    collapsed = []
    for sample in incoming:
        previous = collapsed[-1] if collapsed else None
        if previous and sample['t'] - previous['t'] < ARCHIVE_GAP_MS:
            collapsed[-1] = sample
        else:
            collapsed.append(sample)
    return collapsed[-ARCHIVE_CAP:]


def ensure_archive_loaded():
    global archive_ready
    if archive_ready:
        return
    if not os.path.exists(ARCHIVE_PATH):
        return
    try:
        with open(ARCHIVE_PATH, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError):
        data = []
    if isinstance(data, dict):
        data = data.get('samples', [])
    archive_state[:] = normalize_archive(data)
    archive_ready = True


def write_archive_unlocked():
    global archive_last_flush
    write_json(ARCHIVE_PATH, {'samples': archive_state})
    archive_last_flush = time.time()


def store_sample(values, raw):
    global archive_ready
    now_ms = int(time.time() * 1000)
    sample = {'t': now_ms, 'v': dict(values)}
    if raw:
        sample['r'] = dict(raw)
    with archive_lock:
        ensure_archive_loaded()
        previous = archive_state[-1] if archive_state else None
        new_bucket = previous is None or now_ms - previous['t'] >= ARCHIVE_GAP_MS
        if previous and not new_bucket:
            sample['t'] = previous['t']
            merged = dict(previous.get('v') or {})
            merged.update(values)
            sample['v'] = merged
            merged_raw = dict(previous.get('r') or {})
            merged_raw.update(raw)
            if merged_raw:
                sample['r'] = merged_raw
            archive_state[-1] = sample
        else:
            archive_state.append(sample)
        cutoff = now_ms - ARCHIVE_KEEP_MS
        if archive_state and archive_state[0]['t'] < cutoff:
            archive_state[:] = [item for item in archive_state if item['t'] >= cutoff]
        if len(archive_state) > ARCHIVE_CAP:
            del archive_state[:-ARCHIVE_CAP]
        archive_ready = True
        if new_bucket or time.time() - archive_last_flush >= 60:
            write_archive_unlocked()


def archive_since(since):
    with archive_lock:
        ensure_archive_loaded()
        if not archive_ready:
            return None
        return [dict(item) for item in archive_state if item['t'] >= since]


def replace_archive(samples):
    global archive_ready
    stored = normalize_archive(samples)
    with archive_lock:
        ensure_archive_loaded()
        if archive_ready:
            return [dict(item) for item in archive_state]
        archive_state[:] = stored
        archive_ready = True
        write_archive_unlocked()
        return [dict(item) for item in archive_state]


def clear_archive():
    global archive_ready
    with archive_lock:
        archive_state.clear()
        archive_ready = True
        write_archive_unlocked()


def record_once():
    if load_settings() is None:
        return 20
    config = load_monitor_config()
    if not config:
        return 15
    try:
        interval = int(config.get('view', {}).get('intervalSec', 10))
    except (TypeError, ValueError):
        interval = 10
    interval = min(300, max(10, interval))
    values = {}
    raw = {}
    for item in config['inputs']:
        try:
            area = item.get('range') if item.get('range') in ('I', 'Q') else 'V'
            if area == 'V':
                logo_path = '/pi/rest/vi%d' % item['address']
            else:
                logo_path = '/pi/rest/iq/%s/%d' % (area, item['address'])
            logo_id = item.get('logo') if isinstance(item.get('logo'), str) else ''
            account = find_logo(logo_id)
            status, text = client_for(account['id']).call('GET', logo_path, None, account)
        except RuntimeError as error:
            print('Aufzeichnung: %s' % error)
            continue
        if status != 200:
            continue
        try:
            number = float(str(text).strip())
        except ValueError:
            continue
        divisor = float(item['divisor'])
        scaled = number / divisor
        if abs(scaled) > 50000:
            continue
        values[item['id']] = round(scaled, 3)
        raw[item['id']] = int(number) if number.is_integer() else number
    if values:
        store_sample(values, raw)
    return interval


def recorder_loop():
    while True:
        delay = 20
        try:
            delay = record_once()
        except Exception as error:
            print('Aufzeichnung: %s' % error)
            delay = 30
        time.sleep(delay)


def new_session():
    token = secrets.token_urlsafe(32)
    with sessions_lock:
        now = time.time()
        expired = [key for key, stamp in sessions.items() if now - stamp > SESSION_TTL]
        for key in expired:
            sessions.pop(key, None)
        sessions[token] = now
    return token


def session_valid(token):
    if not token:
        return False
    with sessions_lock:
        stamp = sessions.get(token)
        if stamp is None or time.time() - stamp > SESSION_TTL:
            sessions.pop(token, None)
            return False
        sessions[token] = time.time()
        return True


def drop_session(token):
    if not token:
        return
    with sessions_lock:
        sessions.pop(token, None)


def cookie_token(header):
    if not header:
        return ''
    for part in header.split(';'):
        name, _, value = part.strip().partition('=')
        if name == 'hm_session':
            return value
    return ''


def too_many_attempts(ip):
    now = time.time()
    stamp, count = login_fails.get(ip, (0, 0))
    if now - stamp > 60:
        return False
    return count >= 8


def note_attempt(ip, failed):
    now = time.time()
    stamp, count = login_fails.get(ip, (0, 0))
    if now - stamp > 60:
        count = 0
    if failed:
        login_fails[ip] = (now, count + 1)
    else:
        login_fails.pop(ip, None)


class LogoClient:
    def __init__(self):
        self.lock = threading.Lock()
        self.ctx = ssl.create_default_context()
        self.ctx.check_hostname = False
        self.ctx.verify_mode = ssl.CERT_NONE
        self.mode = ''
        self.hint = ''
        self.cookies = ''
        self.session_id = ''
        self.host = ''
        self.user = ''
        self.password = ''

    def configure_account(self, account):
        host = account['host']
        user = account['user']
        password = account['password']
        if host != self.host or user != self.user or password != self.password:
            self.mode = ''
            self.hint = ''
            self.cookies = ''
            self.session_id = ''
            self.host = host
            self.user = user
            self.password = password

    def configure(self, settings):
        self.configure_account({
            'host': settings['logo_host'],
            'user': settings['logo_user'],
            'password': settings['logo_password'],
        })

    def call(self, method, path, body=None, account=None):
        with self.lock:
            if account is None:
                settings = load_settings()
                if not settings:
                    raise RuntimeError('Die LOGO-Anmeldung ist noch nicht eingerichtet.')
                logos = logo_list(settings)
                if not logos:
                    raise RuntimeError('Die LOGO-Anmeldung ist noch nicht eingerichtet.')
                account = logos[0]
            elif not account.get('host'):
                raise RuntimeError('Die LOGO-Anmeldung ist noch nicht eingerichtet.')
            self.configure_account(account)
            if self.mode == 'logo9':
                return self._runtime_call(method, path, body)
            if self.mode == 'uam':
                return self._logo8_call(method, path, body)
            status, text = self._raw(method, path, body, True, False)
            if status == 404 and (path.startswith('/pi/rest/vi') or path.startswith('/pi/rest/iq/')):
                if self._is_logo8_web():
                    self.mode = 'uam'
                    return self._logo8_call(method, path, body)
                self._logo9_login()
                return self._runtime_call(method, path, body)
            if status not in (401, 403):
                self.mode = 'basic'
                return status, text
            self._uam_login()
            status, text = self._raw(method, path, body, False, True)
            if status not in (401, 403):
                self.mode = 'uam'
            return status, text

    def _store_cookies(self, headers):
        if headers is None:
            return
        found = headers.get_all('Set-Cookie') if hasattr(headers, 'get_all') else None
        if not found:
            return
        jar = {}
        if self.cookies:
            for piece in self.cookies.split(';'):
                name, separator, value = piece.strip().partition('=')
                if separator:
                    jar[name] = value
        for raw in found:
            pair = raw.split(';', 1)[0].strip()
            name, separator, value = pair.partition('=')
            if separator and name:
                jar[name] = value
        self.cookies = '; '.join('%s=%s' % item for item in jar.items())

    def _raw(self, method, path, body, use_basic, use_hint, accept=None):
        headers = {
            'Accept': accept or 'text/plain, application/json',
            'Accept-Encoding': 'identity',
            'User-Agent': 'Heizungsmonitor-QNAP',
        }
        if use_basic and self.user and self.password:
            token = base64.b64encode(('%s:%s' % (self.user, self.password)).encode('utf-8')).decode('ascii')
            headers['Authorization'] = 'Basic ' + token
        if use_hint and self.hint:
            headers['Security-Hint'] = self.hint
        if self.session_id:
            headers['Pseu-Cookie'] = 'Session-Id=' + self.session_id
        if self.cookies:
            headers['Cookie'] = self.cookies
        data = None
        if body is not None:
            data = body.encode('utf-8')
            headers['Content-Type'] = 'text/plain'
        request = urllib.request.Request(self.host + path, data=data, headers=headers, method=method)
        try:
            with self._open(request) as response:
                payload = response.read(8192).decode('utf-8', 'replace')
                self._store_cookies(response.headers)
                return response.status, payload
        except urllib.error.HTTPError as error:
            payload = error.read(8192).decode('utf-8', 'replace')
            self._store_cookies(error.headers)
            return error.code, payload
        except urllib.error.URLError as error:
            print('LOGO nicht erreichbar: %s' % getattr(error, 'reason', error))
            raise RuntimeError('Die LOGO unter %s ist nicht erreichbar. QNAP und LOGO müssen im selben Netz sein.' % self.host)

    def _is_logo8_web(self):
        status, text = self._ajax('Security-Hint', 'p', 'UAMCHAL:3,4,1,2,3,4')
        parts = [part.strip() for part in text.split(',')]
        return status == 200 and len(parts) >= 3 and parts[0] == '700' and parts[2].isdigit()

    def _logo8_post(self, body):
        if not self.hint:
            self._uam_login()
        return self._ajax('Security-Hint', self.hint, body)

    def _logo8_record(self, text):
        match = re.search(r'<r\b([^>]*)/?>', text or '', re.I)
        if not match:
            return None
        attrs = match.group(1)

        def field(name):
            found = re.search(r"\b%s=['\"]([^'\"]*)['\"]" % name, attrs, re.I)
            return found.group(1) if found else None

        return field('e'), field('v')

    def _logo8_value(self, text):
        record = self._logo8_record(text)
        if not record:
            return None
        error, raw = record
        if error not in (None, '0') or not raw:
            return None
        try:
            return int(raw, 16)
        except ValueError:
            return None

    def _logo8_call(self, method, path, body):
        area, address, _query = runtime_query(path)
        if not area or not str(address).isdigit():
            return 400, 'Ungültige Adresse.'
        number = int(address)
        if method == 'GET':
            return self._logo8_read(area, number)
        raw_text = str(body or '').split('(', 1)[0].strip()
        return self._logo8_write(area, number, raw_text)

    def _logo8_read(self, area, number):
        if area == 'V':
            command = 'GETVARS:v1,132,0,%d,1,2' % number
        elif area == 'I':
            command = 'GETVARS:v1,129,0,%d,1,1' % (number - 1)
        elif area == 'Q':
            command = 'GETVARS:v1,130,0,%d,1,1' % (number - 1)
        else:
            return 400, 'Ungültige Adresse.'
        status, text = self._logo8_post(command)
        value = self._logo8_value(text)
        if value is None:
            self._uam_login()
            status, text = self._logo8_post(command)
            value = self._logo8_value(text)
        if value is None:
            return 502, 'Die LOGO 8 hat %s%d nicht geliefert.' % (area, number)
        if area == 'V':
            if value > 32767:
                value -= 65536
            return 200, str(value)
        return 200, '1' if value else '0'

    def _logo8_write(self, area, number, raw_text):
        if area == 'V':
            try:
                raw = int(raw_text)
            except ValueError:
                return 400, 'Ungültiger Wert.'
            if raw < 0:
                raw += 65536
            command = 'SETVARS:v0,132,0,%d,1,2,%04X' % (number, raw & 0xFFFF)
        elif area == 'Q':
            command = 'SETVARS:v0,130,0,%d,1,1,%s' % (number - 1, '01' if raw_text == '1' else '00')
        elif area == 'I':
            command = 'SETVARS:v0,129,0,%d,1,1,%s' % (number - 1, '01' if raw_text == '1' else '00')
        else:
            return 400, 'Ungültige Adresse.'
        status, text = self._logo8_post(command)
        if status in (401, 403):
            self._uam_login()
            status, text = self._logo8_post(command)
        head = (text or '').strip().split(',', 1)[0]
        record = self._logo8_record(text)
        accepted = head in ('700', '') or (record is not None and record[0] in (None, '0'))
        if status != 200 or not accepted:
            return status if status != 200 else 502, 'Die LOGO 8 hat %s%d nicht geschrieben.' % (area, number)
        shown = raw_text
        if area == 'V':
            try:
                shown = str(int(raw_text))
            except ValueError:
                shown = raw_text
        elif area in ('I', 'Q'):
            shown = '1' if raw_text == '1' else '0'
        return 200, shown

    def _uam_login(self):
        keys = [secrets.randbelow(2**32) for _ in range(4)]
        challenge_body = 'UAMCHAL:3,4,%d,%d,%d,%d' % tuple(keys)
        self.hint = ''
        status, text = self._ajax('Security-Hint', 'p', challenge_body)
        parts = [part.strip() for part in text.split(',')]
        if status != 200 or len(parts) < 3 or parts[0] != '700' or not parts[2].isdigit():
            raise RuntimeError('Die LOGO hat die Anmeldung abgelehnt. Benutzer und Passwort prüfen.')
        server_challenge = u32(parts[2])
        pw_token = (self.password + '+' + parts[2])[:32]
        login_token = u32(logo_crc32(pw_token) ^ server_challenge)
        login_challenge = u32(keys[0] ^ keys[1] ^ keys[2] ^ keys[3] ^ server_challenge)
        login_body = 'UAMLOGIN:%s,%d,%d' % (self.user, login_token, login_challenge)
        status, text = self._ajax('Security-Hint', parts[1], login_body)
        logged = [part.strip() for part in text.split(',')]
        if status != 200 or len(logged) < 2 or logged[0] != '700' or not logged[1]:
            raise RuntimeError('Die LOGO hat Benutzer oder Passwort nicht angenommen.')
        self.hint = logged[1]

    def _ajax(self, header_name, header_value, body):
        headers = {
            header_name: header_value,
            'Accept-Encoding': 'identity',
            'Content-Type': 'text/plain',
            'User-Agent': 'Heizungsmonitor-QNAP',
        }
        if self.cookies:
            headers['Cookie'] = self.cookies
        request = urllib.request.Request(
            self.host + '/AJAX',
            data=body.encode('utf-8'),
            headers=headers,
            method='POST',
        )
        try:
            with self._open(request) as response:
                payload = response.read(8192).decode('utf-8', 'replace')
                self._store_cookies(response.headers)
                return response.status, payload
        except urllib.error.HTTPError as error:
            payload = error.read(8192).decode('utf-8', 'replace')
            self._store_cookies(error.headers)
            return error.code, payload

    def _open(self, request):
        if self.host.startswith('https://'):
            return urllib.request.urlopen(request, context=self.ctx, timeout=12)
        return urllib.request.urlopen(request, timeout=12)

    def _logo9_login(self):
        # Eine abgelaufene Sitzung darf die neue Anmeldung nicht begleiten.
        # Die LOGO antwortet sonst mit "er: -102", obwohl Benutzer und Passwort stimmen.
        self.session_id = ''
        self.cookies = ''
        self.hint = ''
        status, text = self._raw('POST', '/login/guest/challenge', self.user, False, False)
        if status != 200 or not text.strip().lower().startswith('ok:'):
            raise RuntimeError('Die LOGO hat die Anmeldung abgelehnt. Benutzer und Passwort prüfen.')
        session = text.split(':', 1)[1].strip()
        password_hash = hashlib.sha256(self.password.encode('utf-8')).hexdigest()
        login_hash = hashlib.sha256((password_hash + session).encode('utf-8')).hexdigest()
        status, text = self._raw('POST', '/login/guest/login', login_hash, False, False)
        if status != 200 or not text.strip().lower().startswith('ok:'):
            if '-104' in text:
                raise RuntimeError('Die LOGO hat Benutzer oder Passwort nicht angenommen.')
            print('LOGO-Anmeldung abgelehnt: %s %s' % (status, ' '.join(text.split())[:40]))
            raise RuntimeError('Die LOGO hat die Anmeldung abgelehnt. Bitte die Seite neu laden.')
        self.session_id = text.split(':', 1)[1].strip()
        self.cookies = 'Session-Id=' + self.session_id
        self.mode = 'logo9'

    def _runtime_call(self, method, path, body):
        area, address, query = runtime_query(path)
        if not query:
            return 400, 'Ungültige Adresse.'
        label = area + address
        if method == 'GET':
            status, text = self._runtime_get(query)
            if status in (401, 403):
                self._logo9_login()
                status, text = self._runtime_get(query)
            if status != 200:
                return status, text or '%s ist nicht lesbar.' % label
            return 200, runtime_value(text, label)
        raw_text = str(body or '').split('(', 1)[0]
        if area == 'V':
            payload = word_payload(int(raw_text))
        else:
            payload = bool_payload(raw_text == '1')
        status, text = self._runtime_post(query, payload)
        if status in (401, 403):
            self._logo9_login()
            status, text = self._runtime_post(query, payload)
        if status == 491:
            return 403, 'Dieser Benutzer darf %s nicht schreiben.' % label
        if status != 200:
            return status, text or 'Schreiben von %s fehlgeschlagen.' % label
        return 200, raw_text

    def _runtime_get(self, path):
        return self._raw('GET', path, None, False, False, accept='application/json')

    def _runtime_post(self, path, payload):
        headers = {
            'Accept': 'application/octet-stream',
            'Accept-Encoding': 'identity',
            'Content-Type': 'application/octet-stream',
            'User-Agent': 'Heizungsmonitor-QNAP',
        }
        if self.session_id:
            headers['Pseu-Cookie'] = 'Session-Id=' + self.session_id
        if self.cookies:
            headers['Cookie'] = self.cookies
        request = urllib.request.Request(self.host + path, data=payload, headers=headers, method='POST')
        try:
            with self._open(request) as response:
                response.read(64)
                self._store_cookies(response.headers)
                return response.status, ''
        except urllib.error.HTTPError as error:
            error.read(256)
            self._store_cookies(error.headers)
            return error.code, ''
        except urllib.error.URLError as error:
            print('LOGO nicht erreichbar: %s' % getattr(error, 'reason', error))
            raise RuntimeError('Die LOGO unter %s ist nicht erreichbar. QNAP und LOGO müssen im selben Netz sein.' % self.host)


LOGO = LogoClient()
logo_clients = {}
logo_clients_lock = threading.Lock()


def client_for(logo_id):
    with logo_clients_lock:
        client = logo_clients.get(logo_id)
        if client is None:
            client = LogoClient()
            logo_clients[logo_id] = client
        return client


def reset_logo_client(logo_id):
    with logo_clients_lock:
        client = logo_clients.pop(logo_id, None)
    if client is None:
        return
    with client.lock:
        client.mode = ''
        client.hint = ''
        client.cookies = ''
        client.session_id = ''
        client.host = ''
        client.user = ''
        client.password = ''


def runtime_query(path):
    if path.startswith('/pi/rest/vi'):
        address = path[len('/pi/rest/vi'):]
        if address.isdigit():
            return 'V', address, '/runtimedata?Vw' + address
    marker = '/pi/rest/iq/'
    if path.startswith(marker):
        area, _, address = path[len(marker):].partition('/')
        if area in ('I', 'Q') and address.isdigit() and 1 <= int(address) <= 128:
            return area, address, '/runtimedata?' + area + address
    return '', '', ''


def bool_payload(on):
    data = bytearray(8)
    data[0] = 1
    data[1] = 1 if on else 0
    return bytes(data)


def word_payload(raw):
    if raw < 0:
        raw += 65536
    data = bytearray(8)
    data[0] = 3
    data[1:5] = (raw & 0xFFFFFFFF).to_bytes(4, 'little')
    return bytes(data)


def runtime_value(text, address):
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        raise RuntimeError('Unerwartete Antwort der LOGO bei %s.' % address)
    result = data.get('result') if isinstance(data, dict) else None
    if not isinstance(result, list) or not result or not isinstance(result[0], dict):
        raise RuntimeError('%s liefert keinen Wert.' % address)
    item = result[0]
    if item.get('type') == 'invalid':
        raise RuntimeError('%s ist in der LOGO nicht lesbar.' % address)
    value = item.get('value')
    if isinstance(value, dict):
        value = value.get('format')
    if isinstance(value, bool):
        return '1' if value else '0'
    if isinstance(value, str):
        number = float(value) if '.' in value else int(value)
        value = int(number) if float(number).is_integer() else number
    if item.get('type') == 'word' and isinstance(value, int) and value > 32767:
        value -= 65536
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


WEATHER_TEXT = {
    0: 'Klar',
    1: 'Überwiegend klar',
    2: 'Teils bewölkt',
    3: 'Bewölkt',
    45: 'Nebel',
    48: 'Nebel',
    51: 'Leichter Niesel',
    53: 'Nieselregen',
    55: 'Starker Niesel',
    56: 'Gefrierender Niesel',
    57: 'Gefrierender Niesel',
    61: 'Leichter Regen',
    63: 'Regen',
    65: 'Starker Regen',
    66: 'Gefrierender Regen',
    67: 'Gefrierender Regen',
    71: 'Leichter Schnee',
    73: 'Schnee',
    75: 'Starker Schnee',
    77: 'Schneegriesel',
    80: 'Leichte Schauer',
    81: 'Regenschauer',
    82: 'Starke Schauer',
    85: 'Schneeschauer',
    86: 'Starke Schneeschauer',
    95: 'Gewitter',
    96: 'Gewitter mit Hagel',
    99: 'Gewitter mit Hagel',
}


def weather_text(code):
    try:
        return WEATHER_TEXT.get(int(code), 'Wetter')
    except (TypeError, ValueError):
        return 'Wetter'


def number_or_none(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    if value != value or value in (float('inf'), float('-inf')):
        return None
    return value


def load_weather_place():
    try:
        with open(WEATHER_PATH, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict):
        return None
    latitude = number_or_none(data.get('latitude'))
    longitude = number_or_none(data.get('longitude'))
    label = str(data.get('label') or '').strip()
    place = str(data.get('place') or '').strip()
    if latitude is None or longitude is None or not label or not place:
        return None
    if not -90 <= latitude <= 90 or not -180 <= longitude <= 180:
        return None
    return {
        'place': place[:80],
        'label': label[:120],
        'latitude': latitude,
        'longitude': longitude,
    }


def save_weather_place(data):
    write_json(WEATHER_PATH, data)


def clear_weather_place():
    try:
        os.remove(WEATHER_PATH)
    except OSError:
        pass


def reset_weather_cache():
    weather_cache['key'] = ''
    weather_cache['at'] = 0.0
    weather_cache['ttl'] = 0.0
    weather_cache['payload'] = None


def https_json(url):
    request = urllib.request.Request(
        url,
        headers={'Accept': 'application/json', 'User-Agent': 'Heizungsmonitor/1.0'},
    )
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            raw = response.read(200_000)
            if getattr(response, 'status', 200) != 200:
                raise RuntimeError('Der Wetterdienst hat die Anfrage abgelehnt.')
    except RuntimeError:
        raise
    except urllib.error.HTTPError as error:
        raise RuntimeError('Der Wetterdienst hat die Anfrage abgelehnt.') from error
    except urllib.error.URLError as error:
        reason = getattr(error, 'reason', None)
        if isinstance(reason, ssl.SSLError):
            raise RuntimeError('Die QNAP kann den Wetterdienst nicht sicher erreichen.') from error
        raise RuntimeError('Der Wetterdienst ist nicht erreichbar.') from error
    except Exception as error:
        raise RuntimeError('Der Wetterdienst ist nicht erreichbar.') from error
    try:
        data = json.loads(raw.decode('utf-8'))
    except (UnicodeError, json.JSONDecodeError) as error:
        raise RuntimeError('Der Wetterdienst hat keine lesbare Antwort geliefert.') from error
    if not isinstance(data, dict):
        raise RuntimeError('Der Wetterdienst hat keine lesbare Antwort geliefert.')
    return data


def clean_place(value):
    text = ' '.join(str(value or '').split())
    if any(ord(char) < 32 for char in text):
        raise ValueError('Der Ort ist ungültig.')
    if not 2 <= len(text) <= 80:
        raise ValueError('Bitte einen Ort eintragen, zum Beispiel Winterthur.')
    return text


def place_label(item):
    name = str(item.get('name') or '').strip()
    admin = str(item.get('admin1') or '').strip()
    if admin.casefold().startswith('kanton '):
        admin = admin[7:].strip()
    country = str(item.get('country') or '').strip()
    parts = [name]
    if admin and admin != name:
        parts.append(admin)
    elif country and country != name:
        parts.append(country)
    return ', '.join(part for part in parts if part)


def lookup_place(value):
    text = clean_place(value)
    query = urllib.parse.urlencode({'name': text, 'count': 5, 'language': 'de', 'format': 'json'})
    data = https_json('https://geocoding-api.open-meteo.com/v1/search?' + query)
    results = [item for item in data.get('results') or [] if isinstance(item, dict)]
    if not results:
        raise ValueError('Diesen Ort kennt der Wetterdienst nicht.')
    chosen = results[0]
    for item in results:
        if str(item.get('country_code') or '') == 'CH' and str(item.get('name') or '').casefold() == text.casefold():
            chosen = item
            break
    latitude = number_or_none(chosen.get('latitude'))
    longitude = number_or_none(chosen.get('longitude'))
    label = place_label(chosen)
    if latitude is None or longitude is None or not label:
        raise RuntimeError('Der Wetterdienst hat keine lesbare Antwort geliefert.')
    return {'place': text, 'label': label[:120], 'latitude': latitude, 'longitude': longitude}


def first_daily(daily, key):
    values = daily.get(key)
    if isinstance(values, list) and values:
        return number_or_none(values[0])
    return None


WEEKDAYS = ('Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag')


def daily_value(values, index):
    if isinstance(values, list) and index < len(values):
        return number_or_none(values[index])
    return None


def daily_rows(daily):
    times = daily.get('time') if isinstance(daily.get('time'), list) else []
    codes = daily.get('weather_code') if isinstance(daily.get('weather_code'), list) else []
    rows = []
    for index, raw in enumerate(times[:7]):
        text = str(raw or '')
        if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', text):
            continue
        try:
            weekday = WEEKDAYS[datetime.date.fromisoformat(text).weekday()]
        except ValueError:
            continue
        code = codes[index] if index < len(codes) else None
        rows.append({
            'date': text,
            'day': weekday,
            'today': index == 0,
            'text': weather_text(code),
            'min': daily_value(daily.get('temperature_2m_min'), index),
            'max': daily_value(daily.get('temperature_2m_max'), index),
            'rain': daily_value(daily.get('precipitation_probability_max'), index),
        })
    return rows


def fetch_forecast(place):
    query = urllib.parse.urlencode({
        'latitude': '%.5f' % place['latitude'],
        'longitude': '%.5f' % place['longitude'],
        'current': 'temperature_2m,apparent_temperature,weather_code,wind_speed_10m',
        'daily': 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max',
        'timezone': 'auto',
        'forecast_days': 7,
    })
    data = https_json('https://api.open-meteo.com/v1/forecast?' + query)
    current = data.get('current') if isinstance(data.get('current'), dict) else {}
    daily = data.get('daily') if isinstance(data.get('daily'), dict) else {}
    code = current.get('weather_code')
    return {
        'enabled': True,
        'place': place['place'],
        'label': place['label'],
        'temperature': number_or_none(current.get('temperature_2m')),
        'apparent': number_or_none(current.get('apparent_temperature')),
        'wind': number_or_none(current.get('wind_speed_10m')),
        'code': int(code) if isinstance(code, (int, float)) and not isinstance(code, bool) else None,
        'text': weather_text(code),
        'min': first_daily(daily, 'temperature_2m_min'),
        'max': first_daily(daily, 'temperature_2m_max'),
        'rain': first_daily(daily, 'precipitation_probability_max'),
        'days': daily_rows(daily),
    }


def current_weather():
    place = load_weather_place()
    if place is None:
        return {'enabled': False}
    key = '%.4f,%.4f' % (place['latitude'], place['longitude'])
    now = time.time()
    with weather_lock:
        cached = weather_cache.get('payload')
        fresh = weather_cache.get('key') == key and cached and now - weather_cache.get('at', 0) < weather_cache.get('ttl', 0)
        if fresh:
            return dict(cached)
    try:
        payload = fetch_forecast(place)
        ttl = WEATHER_TTL
    except RuntimeError as error:
        payload = {
            'enabled': True,
            'place': place['place'],
            'label': place['label'],
            'error': str(error),
        }
        ttl = 60
    with weather_lock:
        weather_cache['key'] = key
        weather_cache['at'] = now
        weather_cache['ttl'] = ttl
        weather_cache['payload'] = payload
    return dict(payload)


def probe_logo(settings):
    client = LogoClient()
    with client.lock:
        client.configure(settings)
        status, _text = client._raw('GET', '/pi/rest/vi202', None, True, False)
        if status == 404:
            if client._is_logo8_web():
                client._uam_login()
                read_status, read_text = client._logo8_read('V', 0)
                if read_status != 200:
                    raise RuntimeError(read_text or 'Die LOGO 8 hat die Werte nicht geliefert.')
                return
            client._logo9_login()
            return
        if status not in (401, 403):
            return
        client._uam_login()
        status, text = client._raw('GET', '/pi/rest/vi202', None, False, True)
        if status in (401, 403):
            preview = ' '.join(text.split())[:80]
            raise RuntimeError('Die LOGO verlangt eine Anmeldung, hat sie aber abgelehnt.' + (' ' + preview if preview else ''))


class Handler(BaseHTTPRequestHandler):
    server_version = 'Heizungsmonitor'
    protocol_version = 'HTTP/1.1'

    def log_message(self, fmt, *args):
        print('%s %s' % (self.address_string(), fmt % args))

    def do_GET(self):
        path = urllib.parse.urlsplit(self.path).path
        if path == '/api/session':
            self.send_json({'ready': load_settings() is not None, 'signedIn': self.signed_in()})
            return
        if path == '/logout':
            drop_session(cookie_token(self.headers.get('Cookie')))
            self.redirect('/login')
            return
        if path == '/setup':
            self.serve_static('setup.html', public=not load_settings())
            return
        if path == '/einstellung':
            if load_settings() is None:
                self.redirect('/setup')
                return
            if not self.signed_in():
                self.redirect('/login')
                return
            self.serve_static('einstellung.html', public=False)
            return
        if path == '/api/connection':
            self.handle_connection_get()
            return
        if path == '/api/logos':
            self.handle_logos_get()
            return
        if path == '/api/weather':
            self.handle_weather_get()
            return
        if path == '/login':
            if load_settings() is None:
                self.redirect('/setup')
                return
            self.serve_static('login.html', public=True)
            return
        if path == '/api/config':
            self.handle_config_get()
            return
        if path == '/api/archive':
            self.handle_archive_get()
            return
        if path.startswith('/api/vi/') or path.startswith('/api/io/'):
            self.proxy('GET', path)
            return
        if path in ('/', '/dashboard.html'):
            if load_settings() is None:
                self.redirect('/setup')
                return
            if not self.signed_in():
                self.redirect('/login')
                return
            self.serve_static('dashboard.html', public=False)
            return
        if path == '/dashboard.css':
            self.serve_static('dashboard.css', public=True)
            return
        if path == '/i18n.js':
            self.serve_static('i18n.js', public=True)
            return
        if path == '/dashboard.js':
            if not self.signed_in():
                self.send_error_text(401, 'Bitte zuerst anmelden.')
                return
            self.serve_static('dashboard.js', public=False)
            return
        self.send_error_text(404, 'Nicht gefunden.')

    def do_POST(self):
        path = urllib.parse.urlsplit(self.path).path
        if path == '/api/login':
            self.handle_login()
            return
        if path == '/api/setup':
            self.handle_setup()
            return
        if path == '/api/connection':
            self.handle_connection_post()
            return
        if path == '/api/logos':
            self.handle_logos_post()
            return
        if path == '/api/weather':
            self.handle_weather_post()
            return
        self.send_error_text(404, 'Nicht gefunden.')

    def do_PUT(self):
        path = urllib.parse.urlsplit(self.path).path
        if path == '/api/config':
            self.handle_config_put()
            return
        if path == '/api/archive':
            self.handle_archive_put()
            return
        if path.startswith('/api/vi/') or path.startswith('/api/io/'):
            self.proxy('PUT', path)
            return
        self.send_error_text(404, 'Nicht gefunden.')

    def do_DELETE(self):
        path = urllib.parse.urlsplit(self.path).path
        if path == '/api/archive':
            self.handle_archive_delete()
            return
        if path.startswith('/api/logos/'):
            self.handle_logos_delete(path[len('/api/logos/'):])
            return
        self.send_error_text(404, 'Nicht gefunden.')

    def signed_in(self):
        return session_valid(cookie_token(self.headers.get('Cookie')))

    def read_json(self, limit=MAX_BODY):
        length = int(self.headers.get('Content-Length', '0') or '0')
        if length < 0 or length > limit:
            raise ValueError('Die Eingabe ist zu gross.')
        raw = self.rfile.read(length) if length else b''
        if not raw:
            return {}
        try:
            data = json.loads(raw.decode('utf-8'))
        except (UnicodeError, json.JSONDecodeError):
            raise ValueError('Ungültige Eingabe.')
        if not isinstance(data, dict):
            raise ValueError('Ungültige Eingabe.')
        return data

    def handle_login(self):
        settings = load_settings()
        if settings is None:
            self.send_json({'ok': False, 'error': 'Bitte zuerst die Einrichtung öffnen.'}, 400)
            return
        ip = self.client_address[0]
        if too_many_attempts(ip):
            self.send_json({'ok': False, 'error': 'Zu viele Versuche. Bitte eine Minute warten.'}, 429)
            return
        try:
            data = self.read_json()
        except ValueError as error:
            self.send_json({'ok': False, 'error': str(error)}, 400)
            return
        password = data.get('password')
        if not isinstance(password, str) or not password_matches(password, settings['app_salt'], settings['app_hash']):
            note_attempt(ip, True)
            self.send_json({'ok': False, 'error': 'Das Anzeigen-Passwort stimmt nicht.'}, 401)
            return
        note_attempt(ip, False)
        token = new_session()
        self.send_json({'ok': True}, 200, {'Set-Cookie': cookie_header(token)})

    def handle_setup(self):
        existing = load_settings()
        if existing is not None and not self.signed_in():
            self.send_json({'ok': False, 'error': 'Bitte zuerst anmelden.'}, 401)
            return
        try:
            data = self.read_json()
            host = check_logo_host(data.get('logoHost'))
            user = str(data.get('logoUser') or '').strip()
            logo_password = data.get('logoPassword')
            app_password = data.get('appPassword')
        except ValueError as error:
            self.send_json({'ok': False, 'error': str(error)}, 400)
            return
        if not user or len(user) > 40 or any(char in user for char in ',\r\n'):
            self.send_json({'ok': False, 'error': 'Der LOGO-Benutzer ist ungültig.'}, 400)
            return
        if not isinstance(logo_password, str) or not logo_password or len(logo_password) > 64:
            self.send_json({'ok': False, 'error': 'Das LOGO-Passwort fehlt.'}, 400)
            return
        if existing is None:
            if not isinstance(app_password, str) or len(app_password) < 6 or len(app_password) > 80:
                self.send_json({'ok': False, 'error': 'Das Anzeigen-Passwort braucht mindestens 6 Zeichen.'}, 400)
                return
            salt, digest = hash_password(app_password)
        else:
            salt, digest = existing['app_salt'], existing['app_hash']
            if isinstance(app_password, str) and app_password:
                if len(app_password) < 6 or len(app_password) > 80:
                    self.send_json({'ok': False, 'error': 'Das Anzeigen-Passwort braucht mindestens 6 Zeichen.'}, 400)
                    return
                salt, digest = hash_password(app_password)
        candidate = {
            'app_salt': salt,
            'app_hash': digest,
            'logo_host': host,
            'logo_user': user,
            'logo_password': logo_password,
        }
        if existing and isinstance(existing.get('logos'), list):
            logos = logo_list(existing)
            if logos:
                logos[0] = dict(logos[0], host=host, user=user, password=logo_password, name=logos[0]['name'])
                candidate['logos'] = logos
        try:
            with settings_lock:
                probe_logo(candidate)
                save_settings(candidate)
                LOGO.mode = ''
                LOGO.hint = ''
                LOGO.cookies = ''
                LOGO.session_id = ''
                reset_logo_client('haupt')
                if candidate.get('logos'):
                    reset_logo_client(candidate['logos'][0]['id'])
        except RuntimeError as error:
            self.send_json({'ok': False, 'error': str(error)}, 502)
            return
        except Exception:
            self.send_json({'ok': False, 'error': 'Die LOGO ist nicht erreichbar.'}, 502)
            return
        token = new_session()
        self.send_json({'ok': True}, 200, {'Set-Cookie': cookie_header(token)})

    def handle_connection_get(self):
        if not self.signed_in():
            self.send_json({'error': 'Bitte zuerst anmelden.'}, 401)
            return
        settings = load_settings()
        if settings is None:
            self.send_json({'error': 'Noch nicht eingerichtet.'}, 404)
            return
        self.send_json({'logoHost': settings['logo_host'], 'logoUser': settings['logo_user']})

    def handle_connection_post(self):
        if not self.signed_in():
            self.send_json({'error': 'Bitte zuerst anmelden.'}, 401)
            return
        existing = load_settings()
        if existing is None:
            self.send_json({'error': 'Noch nicht eingerichtet.'}, 404)
            return
        try:
            data = self.read_json()
            host = check_logo_host(data.get('logoHost'))
            user = str(data.get('logoUser') or '').strip()
            logo_password = data.get('logoPassword')
        except ValueError as error:
            self.send_json({'error': str(error)}, 400)
            return
        if not user or len(user) > 40 or any(char in user for char in ',\r\n'):
            self.send_json({'error': 'Der LOGO-Benutzer ist ungültig.'}, 400)
            return
        if logo_password in (None, ''):
            logo_password = existing['logo_password']
        elif not isinstance(logo_password, str) or len(logo_password) > 64:
            self.send_json({'error': 'Das LOGO-Passwort ist ungültig.'}, 400)
            return
        candidate = {
            'app_salt': existing['app_salt'],
            'app_hash': existing['app_hash'],
            'logo_host': host,
            'logo_user': user,
            'logo_password': logo_password,
        }
        if isinstance(existing.get('logos'), list):
            logos = logo_list(existing)
            if logos:
                logos[0] = dict(logos[0], host=host, user=user, password=logo_password)
                candidate['logos'] = logos
        try:
            with settings_lock:
                probe_logo(candidate)
                save_settings(candidate)
                LOGO.mode = ''
                LOGO.hint = ''
                LOGO.cookies = ''
                LOGO.session_id = ''
                reset_logo_client('haupt')
                if candidate.get('logos'):
                    reset_logo_client(candidate['logos'][0]['id'])
        except RuntimeError as error:
            self.send_json({'error': str(error)}, 502)
            return
        except Exception:
            self.send_json({'error': 'Die LOGO ist nicht erreichbar.'}, 502)
            return
        self.send_json({'ok': True, 'logoHost': host, 'logoUser': user})

    def handle_logos_get(self):
        if not self.signed_in():
            self.send_json({'error': 'Bitte zuerst anmelden.'}, 401)
            return
        settings = load_settings()
        if settings is None:
            self.send_json({'error': 'Noch nicht eingerichtet.'}, 404)
            return
        self.send_json({'logos': [public_logo(item) for item in logo_list(settings)]})

    def handle_logos_post(self):
        if not self.signed_in():
            self.send_json({'error': 'Bitte zuerst anmelden.'}, 401)
            return
        existing = load_settings()
        if existing is None:
            self.send_json({'error': 'Noch nicht eingerichtet.'}, 404)
            return
        try:
            data = self.read_json()
            name = clean_logo_name(data.get('name'))
            host = check_logo_host(data.get('host'))
            user = clean_logo_user(data.get('user'))
            password = data.get('password')
            ident = data.get('id') or ''
        except ValueError as error:
            self.send_json({'error': str(error)}, 400)
            return
        if ident and (not isinstance(ident, str) or not LOGO_ID.match(ident)):
            self.send_json({'error': 'Ungültiges LOGO-Gerät.'}, 400)
            return
        logos = logo_list(existing)
        if not logos:
            self.send_json({'error': 'Noch nicht eingerichtet.'}, 404)
            return
        if ident:
            current = next((item for item in logos if item['id'] == ident), None)
            if current is None:
                self.send_json({'error': 'Dieses LOGO-Gerät ist nicht eingerichtet.'}, 404)
                return
            if password in (None, ''):
                password = current['password']
            elif not isinstance(password, str) or len(password) > 64:
                self.send_json({'error': 'Das LOGO-Passwort ist ungültig.'}, 400)
                return
            if any(item['host'] == host and item['id'] != ident for item in logos):
                self.send_json({'error': 'Diese Adresse ist schon einem Gerät zugeordnet.'}, 400)
                return
            updated = dict(current, name=name, host=host, user=user, password=password)
            stored = [updated if item['id'] == ident else item for item in logos]
        else:
            if len(logos) >= 8:
                self.send_json({'error': 'Höchstens acht LOGO-Geräte.'}, 400)
                return
            if not isinstance(password, str) or not password or len(password) > 64:
                self.send_json({'error': 'Das LOGO-Passwort fehlt.'}, 400)
                return
            if any(item['host'] == host for item in logos):
                self.send_json({'error': 'Diese Adresse ist schon einem Gerät zugeordnet.'}, 400)
                return
            ident = new_logo_id({item['id'] for item in logos})
            updated = {'id': ident, 'name': name, 'host': host, 'user': user, 'password': password}
            stored = logos + [updated]
        candidate = {
            'logo_host': host,
            'logo_user': user,
            'logo_password': password,
        }
        try:
            with settings_lock:
                probe_logo(candidate)
                store_logos(existing, stored)
                reset_logo_client(ident)
        except RuntimeError as error:
            self.send_json({'error': str(error)}, 502)
            return
        except Exception:
            self.send_json({'error': 'Die LOGO ist nicht erreichbar.'}, 502)
            return
        self.send_json({'ok': True, 'logo': public_logo(updated)})

    def handle_logos_delete(self, logo_id):
        if not self.signed_in():
            self.send_json({'error': 'Bitte zuerst anmelden.'}, 401)
            return
        if not LOGO_ID.match(logo_id):
            self.send_json({'error': 'Ungültiges LOGO-Gerät.'}, 400)
            return
        existing = load_settings()
        if existing is None:
            self.send_json({'error': 'Noch nicht eingerichtet.'}, 404)
            return
        logos = logo_list(existing)
        if not any(item['id'] == logo_id for item in logos):
            self.send_json({'error': 'Dieses LOGO-Gerät ist nicht eingerichtet.'}, 404)
            return
        if len(logos) <= 1:
            self.send_json({'error': 'Die letzte LOGO kann nicht entfernt werden.'}, 400)
            return
        if logo_in_use(logo_id, logos[0]['id']):
            self.send_json({'error': 'Diese LOGO wird noch von einem Eingang verwendet. Unter Anpassen zuerst ein anderes Gerät wählen.'}, 400)
            return
        stored = [item for item in logos if item['id'] != logo_id]
        with settings_lock:
            store_logos(existing, stored)
            reset_logo_client(logo_id)
        self.send_json({'ok': True})

    def handle_weather_get(self):
        if not self.signed_in():
            self.send_json({'error': 'Bitte zuerst anmelden.'}, 401)
            return
        self.send_json(current_weather())

    def handle_weather_post(self):
        if not self.signed_in():
            self.send_json({'error': 'Bitte zuerst anmelden.'}, 401)
            return
        try:
            data = self.read_json()
        except ValueError as error:
            self.send_json({'error': str(error)}, 400)
            return
        place = data.get('place')
        if place is None or (isinstance(place, str) and not place.strip()):
            with weather_lock:
                clear_weather_place()
                reset_weather_cache()
            self.send_json({'ok': True, 'enabled': False})
            return
        if not isinstance(place, str):
            self.send_json({'error': 'Der Ort ist ungültig.'}, 400)
            return
        try:
            found = lookup_place(place)
        except ValueError as error:
            self.send_json({'error': str(error)}, 400)
            return
        except RuntimeError as error:
            self.send_json({'error': str(error)}, 502)
            return
        with weather_lock:
            save_weather_place(found)
            reset_weather_cache()
        payload = current_weather()
        payload['ok'] = True
        self.send_json(payload)

    def handle_config_get(self):
        if not self.signed_in():
            self.send_json({'error': 'Bitte zuerst anmelden.'}, 401)
            return
        config = load_monitor_config()
        if config is None:
            self.send_json({'error': 'Noch keine gemeinsamen Eingänge.'}, 404)
            return
        self.send_json(config)

    def handle_config_put(self):
        if not self.signed_in():
            self.send_json({'error': 'Bitte zuerst anmelden.'}, 401)
            return
        try:
            data = self.read_json(CONFIG_BODY)
            stored = save_monitor_config(data)
        except ValueError as error:
            self.send_json({'error': str(error)}, 400)
            return
        self.send_json(stored)

    def handle_archive_get(self):
        if not self.signed_in():
            self.send_json({'error': 'Bitte zuerst anmelden.'}, 401)
            return
        query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
        try:
            since = int(query.get('since', ['0'])[0])
        except ValueError:
            since = 0
        if since < 0:
            since = 0
        samples = archive_since(since)
        if samples is None:
            self.send_json({'samples': []}, 404)
            return
        self.send_json({'samples': samples})

    def handle_archive_put(self):
        if not self.signed_in():
            self.send_json({'error': 'Bitte zuerst anmelden.'}, 401)
            return
        try:
            data = self.read_json(ARCHIVE_BODY)
        except ValueError as error:
            self.send_json({'error': str(error)}, 400)
            return
        samples = data.get('samples') if isinstance(data, dict) else None
        if not isinstance(samples, list):
            self.send_json({'error': 'Ungültige Historie.'}, 400)
            return
        self.send_json({'samples': replace_archive(samples)})

    def handle_archive_delete(self):
        if not self.signed_in():
            self.send_json({'error': 'Bitte zuerst anmelden.'}, 401)
            return
        clear_archive()
        self.send_json({'ok': True})

    def proxy(self, method, path):
        if not self.signed_in():
            self.send_error_text(401, 'Bitte zuerst anmelden.')
            return
        target = parse_proxy_path(path)
        if target is None:
            self.send_error_text(400, 'Ungültige Adresse.')
            return
        logo_id, area, address = target
        digital = area in ('I', 'Q')
        if area == 'V' and not 0 <= address <= 65535:
            self.send_error_text(400, 'Ungültige Adresse.')
            return
        if digital and not 1 <= address <= 128:
            self.send_error_text(400, 'Ungültige Adresse.')
            return
        logo_path = '/pi/rest/vi%d' % address if area == 'V' else '/pi/rest/iq/%s/%d' % (area, address)
        body = None
        if method == 'PUT':
            length = int(self.headers.get('Content-Length', '0') or '0')
            if length < 0 or length > 64:
                self.send_error_text(400, 'Ungültiger Sollwert.')
                return
            raw = self.rfile.read(length).decode('utf-8', 'replace').strip() if length else ''
            if digital and raw not in ('0', '1'):
                self.send_error_text(400, 'I und Q kennen nur Ein oder Aus.')
                return
            if not digital and not valid_setpoint(raw):
                self.send_error_text(400, 'Ungültiger Sollwert.')
                return
            body = raw
        try:
            account = find_logo(logo_id)
            status, text = client_for(account['id']).call(method, logo_path, body, account)
        except RuntimeError as error:
            self.send_error_text(502, str(error))
            return
        if status in (401, 403):
            self.send_error_text(403, 'Anmeldung an der LOGO fehlgeschlagen.')
            return
        payload = text.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(payload)

    def serve_static(self, name, public):
        if name not in ('dashboard.html', 'dashboard.css', 'dashboard.js', 'i18n.js', 'setup.html', 'login.html', 'einstellung.html'):
            self.send_error_text(404, 'Nicht gefunden.')
            return
        if not public and not self.signed_in():
            self.redirect('/login')
            return
        full = os.path.join(STATIC_DIR, name)
        try:
            with open(full, 'rb') as handle:
                payload = handle.read()
        except OSError:
            self.send_error_text(404, 'Nicht gefunden.')
            return
        kind = 'text/html' if name.endswith('.html') else 'text/css' if name.endswith('.css') else 'text/javascript'
        self.send_response(200)
        self.send_header('Content-Type', kind + '; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(payload)

    def redirect(self, location):
        self.send_response(302)
        self.send_header('Location', location)
        self.send_header('Content-Length', '0')
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()

    def send_json(self, data, status=200, extra=None):
        payload = json.dumps(data).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store')
        if extra:
            for key, value in extra.items():
                self.send_header(key, value)
        self.end_headers()
        self.wfile.write(payload)

    def send_error_text(self, status, message):
        payload = message.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(payload)


def cookie_header(token):
    return 'hm_session=%s; HttpOnly; SameSite=Lax; Path=/; Max-Age=%d' % (token, SESSION_TTL)


def valid_setpoint(text):
    if len(text) > 40:
        return False
    core = text
    if '(' in text:
        core, _, suffix = text.partition('(')
        if not suffix.endswith(')') or not suffix[:-1].isalpha() or not (1 <= len(suffix[:-1]) <= 4):
            return False
    if not core or (core[0] == '-' and not core[1:].isdigit()) or (core[0] != '-' and not core.isdigit()):
        return False
    try:
        number = int(core)
    except ValueError:
        return False
    return -32768 <= number <= 32767


def main():
    os.makedirs(DATA_DIR, exist_ok=True)
    with archive_lock:
        ensure_archive_loaded()
    threading.Thread(target=recorder_loop, name='aufzeichnung', daemon=True).start()
    server = ThreadingHTTPServer(('0.0.0.0', PORT), Handler)
    print('Heizungsmonitor hört auf Port %d' % PORT)
    server.serve_forever()


if __name__ == '__main__':
    main()
